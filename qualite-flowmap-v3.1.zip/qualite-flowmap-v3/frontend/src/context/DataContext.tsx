import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import type { FlowConfig, Node, QmsDocument, RoleDefinition, MetierDefinition, Project } from '../types';
import initialFlowData from '../data/flow.json';
import * as api from '../services/api';

/**
 * Interface pour un document QMS avec fichier stocké sur le serveur
 */
export interface QmsDocumentWithFile extends QmsDocument {
  /** Nom du fichier original */
  fileName?: string;
  /** Nom du fichier stocké sur le serveur */
  storedFileName?: string;
}

/**
 * Interface pour un nœud avec documents enrichis
 */
export interface NodeWithFiles extends Omit<Node, 'qmsDocuments'> {
  qmsDocuments?: QmsDocumentWithFile[];
}

interface DataContextType {
  // État
  flowData: FlowConfig;
  nodes: NodeWithFiles[];
  isLoading: boolean;
  error: string | null;
  isConnected: boolean;
  
  // === V3.1 - Rôles ===
  roles: RoleDefinition[];
  createRole: (name: string, color?: string) => Promise<void>;
  updateRole: (id: string, updates: Partial<RoleDefinition>) => Promise<void>;
  deleteRole: (id: string) => Promise<void>;
  
  // === V3.1 - Métiers ===
  metiers: MetierDefinition[];
  createMetier: (name: string, color?: string, icon?: string) => Promise<void>;
  updateMetier: (id: string, updates: Partial<MetierDefinition>) => Promise<void>;
  deleteMetier: (id: string) => Promise<void>;
  
  // === V3.1 - Projets ===
  projects: Project[];
  selectedProject: Project | null;
  selectProject: (project: Project | null) => void;
  createProject: (affaireNumber: string, chantierName: string) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  advanceProjectStep: (projectId: string, comment?: string) => Promise<void>;
  
  // === V3.1 - Gestion des cartes ===
  createNode: (data: Partial<NodeWithFiles>) => Promise<void>;
  deleteNode: (nodeId: string) => Promise<void>;
  
  // Actions sur les nœuds
  updateNode: (nodeId: string, updates: Partial<NodeWithFiles>) => Promise<void>;
  
  // Actions sur les documents QMS
  addDocument: (nodeId: string, document: Partial<QmsDocumentWithFile>, file?: File) => Promise<void>;
  updateDocument: (nodeId: string, docIndex: number, updates: Partial<QmsDocumentWithFile>, file?: File) => Promise<void>;
  deleteDocument: (nodeId: string, docIndex: number) => Promise<void>;
  
  // Architecture PDF
  architectureInfo: { exists: boolean; originalName?: string } | null;
  uploadArchitecturePdf: (file: File) => Promise<void>;
  deleteArchitecturePdf: () => Promise<void>;
  getArchitecturePdfUrl: () => string;
  
  // Reset et refresh
  resetToDefaults: () => Promise<void>;
  refreshData: () => Promise<void>;
  
  // Export/Import
  exportData: () => Promise<string>;
  importData: (jsonData: string) => Promise<boolean>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

/**
 * Provider pour la gestion des données avec backend
 * V3.1 : Ajout des rôles, métiers et projets
 */
export function DataProvider({ children }: { children: ReactNode }) {
  const [nodes, setNodes] = useState<NodeWithFiles[]>(initialFlowData.nodes as NodeWithFiles[]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [architectureInfo, setArchitectureInfo] = useState<{ exists: boolean; originalName?: string } | null>(null);
  
  // V3.1 - Nouveaux états
  const [roles, setRoles] = useState<RoleDefinition[]>([]);
  const [metiers, setMetiers] = useState<MetierDefinition[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // Charger les données au démarrage
  const loadData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Charger les données du flux
      const response = await api.getFlowData();
      
      if (response.flow && response.flow.nodes) {
        setNodes(response.flow.nodes);
      } else {
        // Initialiser avec les données par défaut
        await api.initFlowData(initialFlowData);
        setNodes(initialFlowData.nodes as NodeWithFiles[]);
      }
      
      // Charger info architecture
      const archInfo = await api.getArchitectureInfo();
      setArchitectureInfo(archInfo);
      
      // V3.1 - Charger rôles, métiers et projets
      const rolesData = await api.getRoles();
      setRoles(rolesData.roles || []);
      
      const metiersData = await api.getMetiers();
      setMetiers(metiersData.metiers || []);
      
      const projectsData = await api.getProjects();
      setProjects(projectsData.projects || []);
      
      setIsConnected(true);
    } catch (err) {
      console.error('Erreur de connexion au serveur:', err);
      setError(err instanceof Error ? err.message : 'Erreur de connexion');
      setIsConnected(false);
      // Utiliser les données locales par défaut
      setNodes(initialFlowData.nodes as NodeWithFiles[]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Données du flux (phases et lanes sont statiques)
  const flowData: FlowConfig = {
    ...initialFlowData,
    nodes: nodes as Node[]
  };

  // Rafraîchir les données
  const refreshData = async () => {
    await loadData();
  };

  // ============================================
  // V3.1 - GESTION DES RÔLES
  // ============================================

  const createRoleFn = async (name: string, color?: string) => {
    try {
      const result = await api.createRole(name, color);
      setRoles(prev => [...prev, result.role]);
    } catch (err) {
      console.error('Erreur création rôle:', err);
      throw err;
    }
  };

  const updateRoleFn = async (id: string, updates: Partial<RoleDefinition>) => {
    try {
      const result = await api.updateRole(id, updates);
      setRoles(prev => prev.map(r => r.id === id ? result.role : r));
    } catch (err) {
      console.error('Erreur modification rôle:', err);
      throw err;
    }
  };

  const deleteRoleFn = async (id: string) => {
    try {
      await api.deleteRole(id);
      setRoles(prev => prev.filter(r => r.id !== id));
    } catch (err) {
      console.error('Erreur suppression rôle:', err);
      throw err;
    }
  };

  // ============================================
  // V3.1 - GESTION DES MÉTIERS
  // ============================================

  const createMetierFn = async (name: string, color?: string, icon?: string) => {
    try {
      const result = await api.createMetier(name, color, icon);
      setMetiers(prev => [...prev, result.metier]);
    } catch (err) {
      console.error('Erreur création métier:', err);
      throw err;
    }
  };

  const updateMetierFn = async (id: string, updates: Partial<MetierDefinition>) => {
    try {
      const result = await api.updateMetier(id, updates);
      setMetiers(prev => prev.map(m => m.id === id ? result.metier : m));
    } catch (err) {
      console.error('Erreur modification métier:', err);
      throw err;
    }
  };

  const deleteMetierFn = async (id: string) => {
    try {
      await api.deleteMetier(id);
      setMetiers(prev => prev.filter(m => m.id !== id));
    } catch (err) {
      console.error('Erreur suppression métier:', err);
      throw err;
    }
  };

  // ============================================
  // V3.1 - GESTION DES PROJETS
  // ============================================

  const selectProject = (project: Project | null) => {
    setSelectedProject(project);
  };

  const createProjectFn = async (affaireNumber: string, chantierName: string) => {
    try {
      const result = await api.createProject(affaireNumber, chantierName);
      setProjects(prev => [...prev, result.project]);
    } catch (err) {
      console.error('Erreur création projet:', err);
      throw err;
    }
  };

  const deleteProjectFn = async (id: string) => {
    try {
      await api.deleteProject(id);
      setProjects(prev => prev.filter(p => p.id !== id));
      // Désélectionner si c'était le projet actif
      if (selectedProject?.id === id) {
        setSelectedProject(null);
      }
    } catch (err) {
      console.error('Erreur suppression projet:', err);
      throw err;
    }
  };

  const advanceProjectStepFn = async (projectId: string, comment?: string) => {
    try {
      const result = await api.advanceProjectStep(projectId, comment);
      // Mettre à jour le projet dans la liste
      setProjects(prev => prev.map(p => p.id === projectId ? result.project : p));
      // Mettre à jour le projet sélectionné si c'est lui
      if (selectedProject?.id === projectId) {
        setSelectedProject(result.project);
      }
    } catch (err) {
      console.error('Erreur avancement étape:', err);
      throw err;
    }
  };

  // ============================================
  // V3.1 - GESTION DES CARTES (NODES)
  // ============================================

  const createNodeFn = async (data: Partial<NodeWithFiles>) => {
    try {
      const result = await api.createNode(data);
      setNodes(prev => [...prev, result.node]);
    } catch (err) {
      console.error('Erreur création carte:', err);
      throw err;
    }
  };

  const deleteNodeFn = async (nodeId: string) => {
    try {
      await api.deleteNode(nodeId);
      setNodes(prev => prev.filter(n => n.id !== nodeId));
    } catch (err) {
      console.error('Erreur suppression carte:', err);
      throw err;
    }
  };

  // Mettre à jour un nœud
  const updateNode = async (nodeId: string, updates: Partial<NodeWithFiles>) => {
    try {
      await api.updateNode(nodeId, updates);
      
      // Mettre à jour l'état local
      setNodes(prev => prev.map(node => 
        node.id === nodeId ? { ...node, ...updates } : node
      ));
    } catch (err) {
      console.error('Erreur mise à jour nœud:', err);
      throw err;
    }
  };

  // Ajouter un document QMS
  const addDocument = async (nodeId: string, document: Partial<QmsDocumentWithFile>, file?: File) => {
    try {
      const result = await api.addDocument(nodeId, document, file);
      
      // Mettre à jour l'état local
      setNodes(prev => prev.map(node => {
        if (node.id === nodeId) {
          const currentDocs = node.qmsDocuments || [];
          return {
            ...node,
            qmsDocuments: [...currentDocs, result.document]
          };
        }
        return node;
      }));
    } catch (err) {
      console.error('Erreur ajout document:', err);
      throw err;
    }
  };

  // Modifier un document QMS
  const updateDocument = async (nodeId: string, docIndex: number, updates: Partial<QmsDocumentWithFile>, file?: File) => {
    try {
      const node = nodes.find(n => n.id === nodeId);
      if (!node || !node.qmsDocuments) return;
      
      const currentDoc = node.qmsDocuments[docIndex];
      const updatedDoc = { ...currentDoc, ...updates };
      
      const result = await api.updateDocument(nodeId, docIndex, updatedDoc, file);
      
      // Mettre à jour l'état local
      setNodes(prev => prev.map(n => {
        if (n.id === nodeId && n.qmsDocuments) {
          const newDocs = [...n.qmsDocuments];
          newDocs[docIndex] = result.document;
          return { ...n, qmsDocuments: newDocs };
        }
        return n;
      }));
    } catch (err) {
      console.error('Erreur modification document:', err);
      throw err;
    }
  };

  // Supprimer un document QMS
  const deleteDocument = async (nodeId: string, docIndex: number) => {
    try {
      await api.deleteDocument(nodeId, docIndex);
      
      // Mettre à jour l'état local
      setNodes(prev => prev.map(node => {
        if (node.id === nodeId && node.qmsDocuments) {
          const newDocs = node.qmsDocuments.filter((_, i) => i !== docIndex);
          return { ...node, qmsDocuments: newDocs };
        }
        return node;
      }));
    } catch (err) {
      console.error('Erreur suppression document:', err);
      throw err;
    }
  };

  // Upload PDF architecture
  const uploadArchitecturePdf = async (file: File) => {
    try {
      await api.uploadArchitecturePdf(file);
      const archInfo = await api.getArchitectureInfo();
      setArchitectureInfo(archInfo);
    } catch (err) {
      console.error('Erreur upload PDF:', err);
      throw err;
    }
  };

  // Supprimer PDF architecture
  const deleteArchitecturePdf = async () => {
    try {
      await api.deleteArchitecturePdf();
      setArchitectureInfo({ exists: false });
    } catch (err) {
      console.error('Erreur suppression PDF:', err);
      throw err;
    }
  };

  // URL du PDF architecture
  const getArchitecturePdfUrl = () => {
    return api.getArchitecturePdfUrl();
  };

  // Réinitialiser aux valeurs par défaut
  const resetToDefaults = async () => {
    try {
      await api.resetAllData();
      await api.initFlowData(initialFlowData);
      setNodes(initialFlowData.nodes as NodeWithFiles[]);
      setArchitectureInfo({ exists: false });
      setRoles([]);
      setMetiers([]);
      setProjects([]);
      setSelectedProject(null);
      // Recharger pour avoir les valeurs par défaut
      await loadData();
    } catch (err) {
      console.error('Erreur réinitialisation:', err);
      throw err;
    }
  };

  // Exporter les données en JSON
  const exportData = async (): Promise<string> => {
    try {
      const data = await api.exportData();
      return JSON.stringify(data, null, 2);
    } catch (err) {
      console.error('Erreur export:', err);
      throw err;
    }
  };

  // Importer des données depuis JSON
  const importDataFn = async (jsonData: string): Promise<boolean> => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed.flow && parsed.flow.nodes) {
        await api.importData(parsed.flow);
        setNodes(parsed.flow.nodes);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Erreur import:', err);
      return false;
    }
  };

  return (
    <DataContext.Provider value={{
      flowData,
      nodes,
      isLoading,
      error,
      isConnected,
      // V3.1 - Rôles
      roles,
      createRole: createRoleFn,
      updateRole: updateRoleFn,
      deleteRole: deleteRoleFn,
      // V3.1 - Métiers
      metiers,
      createMetier: createMetierFn,
      updateMetier: updateMetierFn,
      deleteMetier: deleteMetierFn,
      // V3.1 - Projets
      projects,
      selectedProject,
      selectProject,
      createProject: createProjectFn,
      deleteProject: deleteProjectFn,
      advanceProjectStep: advanceProjectStepFn,
      // V3.1 - Cartes
      createNode: createNodeFn,
      deleteNode: deleteNodeFn,
      // Existant
      updateNode,
      addDocument,
      updateDocument,
      deleteDocument,
      architectureInfo,
      uploadArchitecturePdf,
      deleteArchitecturePdf,
      getArchitecturePdfUrl,
      resetToDefaults,
      refreshData,
      exportData,
      importData: importDataFn
    }}>
      {children}
    </DataContext.Provider>
  );
}

/**
 * Hook pour utiliser le contexte de données
 */
export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}

/**
 * Helper pour obtenir l'URL de téléchargement d'un document
 */
export function getDocumentDownloadUrl(storedFileName: string) {
  return api.getDocumentDownloadUrl(storedFileName);
}
