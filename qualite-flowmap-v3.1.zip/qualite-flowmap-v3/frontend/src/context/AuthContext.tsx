import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

/**
 * Types pour la gestion des utilisateurs et des modes
 */
export type UserRole = 'user' | 'admin';

export interface User {
  role: UserRole;
  name: string;
}

interface AuthContextType {
  user: User;
  isAdmin: boolean;
  login: (password: string) => boolean;
  logout: () => void;
  toggleMode: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mot de passe admin simple (à personnaliser)
// Dans une vraie application, utiliser un système d'authentification sécurisé
const ADMIN_PASSWORD = 'admin123';

/**
 * Provider pour le contexte d'authentification
 * Gère le basculement entre mode Utilisateur et mode Admin
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>(() => {
    // Récupérer l'état sauvegardé dans localStorage
    const saved = localStorage.getItem('qualite-flowmap-user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return { role: 'user' as UserRole, name: 'Utilisateur' };
      }
    }
    return { role: 'user' as UserRole, name: 'Utilisateur' };
  });

  // Sauvegarder l'état dans localStorage
  useEffect(() => {
    localStorage.setItem('qualite-flowmap-user', JSON.stringify(user));
  }, [user]);

  const isAdmin = user.role === 'admin';

  const login = (password: string): boolean => {
    if (password === ADMIN_PASSWORD) {
      setUser({ role: 'admin', name: 'Administrateur' });
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser({ role: 'user', name: 'Utilisateur' });
  };

  const toggleMode = () => {
    if (isAdmin) {
      logout();
    }
    // Si user, il faut passer par login() avec mot de passe
  };

  return (
    <AuthContext.Provider value={{ user, isAdmin, login, logout, toggleMode }}>
      {children}
    </AuthContext.Provider>
  );
}

/**
 * Hook pour utiliser le contexte d'authentification
 */
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
