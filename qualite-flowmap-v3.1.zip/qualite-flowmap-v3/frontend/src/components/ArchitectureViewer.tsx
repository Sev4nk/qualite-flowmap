import React, { useRef, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

/**
 * Composant pour afficher l'architecture des dossiers QMS
 * Affiche le PDF FM_F550_Compliance_Matrix stocké sur le serveur
 * - Mode User : consultation uniquement
 * - Mode Admin : possibilité de mettre à jour le PDF
 */
export default function ArchitectureViewer() {
  const { isAdmin } = useAuth();
  const { 
    architectureInfo, 
    uploadArchitecturePdf, 
    deleteArchitecturePdf, 
    getArchitecturePdfUrl,
    isConnected 
  } = useData();
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  // Gérer l'upload du PDF
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      alert('Veuillez sélectionner un fichier PDF');
      return;
    }

    // Vérifier la taille (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('Le fichier est trop volumineux (max 10 Mo)');
      return;
    }

    setIsUploading(true);
    try {
      await uploadArchitecturePdf(file);
    } catch (err) {
      alert('Erreur lors de l\'upload : ' + (err instanceof Error ? err.message : 'Erreur inconnue'));
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Supprimer le PDF
  const handleRemove = async () => {
    if (confirm('Êtes-vous sûr de vouloir supprimer le PDF d\'architecture ?')) {
      try {
        await deleteArchitecturePdf();
      } catch (err) {
        alert('Erreur lors de la suppression : ' + (err instanceof Error ? err.message : 'Erreur inconnue'));
      }
    }
  };

  // Télécharger le PDF
  const handleDownload = () => {
    if (architectureInfo?.exists) {
      window.open(getArchitecturePdfUrl(), '_blank');
    }
  };

  const pdfExists = architectureInfo?.exists;

  return (
    <div className="architecture-viewer">
      {/* En-tête */}
      <div className="architecture-header">
        <div className="architecture-title">
          <h2>📁 Architecture des dossiers QMS</h2>
          <p className="architecture-subtitle">
            FM_F550_Compliance_Matrix - Organisation des documents qualité
            {architectureInfo?.originalName && (
              <span className="file-name"> ({architectureInfo.originalName})</span>
            )}
          </p>
        </div>

        <div className="architecture-actions">
          {/* Indicateur de connexion */}
          {!isConnected && (
            <span className="connection-status disconnected">⚠️ Serveur déconnecté</span>
          )}

          {pdfExists && (
            <button className="btn-download" onClick={handleDownload}>
              ⬇️ Télécharger
            </button>
          )}

          {isAdmin && isConnected && (
            <>
              <label className={`btn-upload ${isUploading ? 'disabled' : ''}`}>
                {isUploading ? '⏳ Envoi...' : `📤 ${pdfExists ? 'Remplacer' : 'Importer'} PDF`}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  style={{ display: 'none' }}
                  disabled={isUploading}
                />
              </label>

              {pdfExists && (
                <button 
                  className="btn-remove" 
                  onClick={handleRemove}
                  disabled={isUploading}
                >
                  🗑️ Supprimer
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Contenu */}
      <div className="architecture-content">
        {!isConnected ? (
          <div className="no-pdf">
            <div className="no-pdf-icon">🔌</div>
            <h3>Serveur non connecté</h3>
            <p>
              Impossible de charger le document d'architecture.
              Vérifiez que le serveur backend est démarré.
            </p>
          </div>
        ) : pdfExists ? (
          <div className="pdf-container">
            <iframe
              src={getArchitecturePdfUrl()}
              title="Architecture des dossiers QMS"
              className="pdf-iframe"
            />
          </div>
        ) : (
          <div className="no-pdf">
            <div className="no-pdf-icon">📄</div>
            <h3>Aucun document d'architecture</h3>
            <p>
              {isAdmin 
                ? 'Importez le fichier PDF FM_F550_Compliance_Matrix pour afficher l\'architecture des dossiers QMS.'
                : 'Le document d\'architecture n\'a pas encore été importé par un administrateur.'
              }
            </p>
            {isAdmin && (
              <label className={`btn-upload-large ${isUploading ? 'disabled' : ''}`}>
                {isUploading ? '⏳ Envoi en cours...' : '📤 Importer le PDF'}
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  style={{ display: 'none' }}
                  disabled={isUploading}
                />
              </label>
            )}
          </div>
        )}
      </div>

      {/* Info */}
      <div className="architecture-info">
        <p>
          💡 Ce document présente l'arborescence complète des dossiers QMS sur le serveur :
          <code>P:\Labenne\Ss traitance\INDUSTRIALISATION\PROJET\2023-FM GLOBAL</code>
        </p>
      </div>
    </div>
  );
}
