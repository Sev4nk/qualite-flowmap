import React, { useState, useEffect } from 'react';
import type { Phase, Lane, StepStatus } from '../types';
import { useAuth } from '../context/AuthContext';
import { useData, NodeWithFiles } from '../context/DataContext';
import QmsDocumentsManager from './QmsDocumentsManager';

interface StepPanelProps {
  node: NodeWithFiles | null;
  phase: Phase | null;
  lane: Lane | null;
  onClose: () => void;
  /** V3.1 - Statut de l'étape dans le projet (si un projet est sélectionné) */
  stepStatus?: StepStatus;
  /** V3.1 - Callback pour valider l'étape active */
  onValidateStep?: () => void;
}

/**
 * Panneau latéral affichant les détails complets d'une étape.
 * V3.1 : 
 * - Listes déroulantes pour les rôles (pas de saisie libre)
 * - Affichage du statut si projet sélectionné
 * - Bouton "Étape OK" pour l'étape active
 */
export default function StepPanel({ 
  node, 
  phase, 
  lane, 
  onClose,
  stepStatus,
  onValidateStep 
}: StepPanelProps) {
  const { isAdmin } = useAuth();
  const { updateNode, roles } = useData();
  
  // État d'édition
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<NodeWithFiles>>({});

  // Réinitialiser l'état d'édition quand le nœud change
  useEffect(() => {
    if (node) {
      setEditData({
        title: node.title,
        shortDescription: node.shortDescription,
        mainRole: node.mainRole,
        secondaryRoles: node.secondaryRoles || [],
        conditions: node.conditions || [],
        notes: node.notes || ''
      });
    }
    setIsEditing(false);
  }, [node]);

  if (!node || !phase || !lane) {
    return null;
  }

  // Sauvegarder les modifications
  const handleSave = async () => {
    try {
      await updateNode(node.id, editData);
      setIsEditing(false);
    } catch (err) {
      alert('Erreur lors de la sauvegarde');
    }
  };

  // Annuler les modifications
  const handleCancel = () => {
    setEditData({
      title: node.title,
      shortDescription: node.shortDescription,
      mainRole: node.mainRole,
      secondaryRoles: node.secondaryRoles || [],
      conditions: node.conditions || [],
      notes: node.notes || ''
    });
    setIsEditing(false);
  };

  // Gérer les rôles secondaires (checkboxes)
  const handleSecondaryRoleToggle = (roleId: string) => {
    const current = editData.secondaryRoles || [];
    if (current.includes(roleId)) {
      setEditData(prev => ({ 
        ...prev, 
        secondaryRoles: current.filter(r => r !== roleId) 
      }));
    } else {
      setEditData(prev => ({ 
        ...prev, 
        secondaryRoles: [...current, roleId] 
      }));
    }
  };

  // Gérer les conditions (string séparé par des retours à la ligne)
  const handleConditionsChange = (value: string) => {
    const conditions = value.split('\n').map(c => c.trim()).filter(c => c);
    setEditData(prev => ({ ...prev, conditions }));
  };

  // Obtenir le nom d'un rôle par son ID
  const getRoleName = (roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    return role ? role.name : roleId; // Fallback sur l'ID si non trouvé
  };

  // Indicateur de statut (V3.1)
  const getStatusIndicator = () => {
    if (!stepStatus) return null;
    
    switch (stepStatus) {
      case 'locked':
        return <span className="status-badge status-locked">🔒 Verrouillée</span>;
      case 'active':
        return <span className="status-badge status-active">▶️ Active</span>;
      case 'done':
        return <span className="status-badge status-done">✅ Terminée</span>;
      default:
        return null;
    }
  };

  return (
    <div className="step-panel-overlay" onClick={onClose}>
      <div className="step-panel" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="panel-header" style={{ backgroundColor: lane.color }}>
          <button className="btn-close" onClick={onClose} aria-label="Fermer">
            ✕
          </button>
          <div className="panel-badge">
            <span className="phase-badge">Phase {phase.id}</span>
            <span className="lane-badge">{lane.icon} {lane.name}</span>
            {/* V3.1 - Statut de l'étape */}
            {getStatusIndicator()}
          </div>
          
          {isEditing ? (
            <input
              type="text"
              className="edit-title"
              value={editData.title || ''}
              onChange={e => setEditData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Titre de l'étape"
            />
          ) : (
            <h2 className="panel-title">{node.title}</h2>
          )}
          
          <span className="panel-id">{node.id}</span>

          {/* Boutons d'édition (Admin) */}
          {isAdmin && (
            <div className="panel-edit-actions">
              {isEditing ? (
                <>
                  <button className="btn-save" onClick={handleSave}>✓ Sauvegarder</button>
                  <button className="btn-cancel" onClick={handleCancel}>✕ Annuler</button>
                </>
              ) : (
                <button className="btn-edit-mode" onClick={() => setIsEditing(true)}>
                  ✏️ Modifier
                </button>
              )}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="panel-content">
          {/* V3.1 - Bouton "Étape OK" pour l'étape active */}
          {stepStatus === 'active' && onValidateStep && (
            <div className="validate-step-section">
              <button 
                className="btn-validate-step"
                onClick={onValidateStep}
              >
                ✅ Étape OK - Passer à la suivante
              </button>
            </div>
          )}

          {/* 📋 Objectif */}
          <section className="panel-section">
            <h3>📋 Objectif</h3>
            {isEditing ? (
              <textarea
                className="edit-textarea"
                value={editData.shortDescription || ''}
                onChange={e => setEditData(prev => ({ ...prev, shortDescription: e.target.value }))}
                placeholder="Description de l'objectif..."
                rows={3}
              />
            ) : (
              <p>{node.shortDescription || <span className="no-data">Non défini</span>}</p>
            )}
          </section>

          {/* 👥 Responsabilités - V3.1 : Listes déroulantes */}
          <section className="panel-section">
            <h3>👥 Responsabilités</h3>
            <div className="roles-list">
              {/* Rôle principal - Select */}
              <div className="role-item role-main">
                <span className="role-label">Responsable principal :</span>
                {isEditing ? (
                  <select
                    className="edit-select"
                    value={editData.mainRole || ''}
                    onChange={e => setEditData(prev => ({ ...prev, mainRole: e.target.value }))}
                  >
                    <option value="">-- Sélectionner un rôle --</option>
                    {roles.map(role => (
                      <option key={role.id} value={role.id}>
                        {role.name}
                      </option>
                    ))}
                  </select>
                ) : (
                  <span className="role-value">
                    {node.mainRole ? getRoleName(node.mainRole) : <span className="no-data">Non défini</span>}
                  </span>
                )}
              </div>
              
              {/* Rôles secondaires - Checkboxes */}
              <div className="role-item role-secondary">
                <span className="role-label">En support :</span>
                {isEditing ? (
                  <div className="roles-checkboxes">
                    {roles.map(role => (
                      <label key={role.id} className="role-checkbox">
                        <input
                          type="checkbox"
                          checked={(editData.secondaryRoles || []).includes(role.id)}
                          onChange={() => handleSecondaryRoleToggle(role.id)}
                        />
                        <span style={{ color: role.color }}>{role.name}</span>
                      </label>
                    ))}
                  </div>
                ) : (
                  <span className="role-value">
                    {node.secondaryRoles && node.secondaryRoles.length > 0 
                      ? node.secondaryRoles.map(r => getRoleName(r)).join(', ')
                      : <span className="no-data">–</span>
                    }
                  </span>
                )}
              </div>
            </div>
          </section>

          {/* 📄 Documents QMS */}
          <section className="panel-section">
            <QmsDocumentsManager 
              nodeId={node.id}
              documents={node.qmsDocuments || []}
            />
          </section>

          {/* 🚦 Conditions GO / NO GO */}
          <section className="panel-section">
            <h3>🚦 Conditions GO / NO GO</h3>
            {isEditing ? (
              <textarea
                className="edit-textarea"
                value={(editData.conditions || []).join('\n')}
                onChange={e => handleConditionsChange(e.target.value)}
                placeholder="Une condition par ligne..."
                rows={4}
              />
            ) : (
              node.conditions && node.conditions.length > 0 ? (
                <ul className="conditions-list">
                  {node.conditions.map((condition, index) => (
                    <li key={index}>{condition}</li>
                  ))}
                </ul>
              ) : (
                <p className="no-data">Aucune condition définie.</p>
              )
            )}
          </section>

          {/* 💡 Notes & Rappels */}
          <section className="panel-section panel-notes">
            <h3>💡 Notes & Rappels</h3>
            {isEditing ? (
              <textarea
                className="edit-textarea"
                value={editData.notes || ''}
                onChange={e => setEditData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Notes libres..."
                rows={3}
              />
            ) : (
              node.notes ? (
                <p>{node.notes}</p>
              ) : (
                <p className="no-data">Aucune note.</p>
              )
            )}
          </section>
        </div>

        {/* Footer */}
        <div className="panel-footer">
          <span className="panel-phase-info">
            Phase {phase.id} – {phase.name}
          </span>
          {isAdmin && !isEditing && (
            <span className="admin-hint">💡 Cliquez sur "Modifier" pour éditer cette fiche</span>
          )}
        </div>
      </div>
    </div>
  );
}
