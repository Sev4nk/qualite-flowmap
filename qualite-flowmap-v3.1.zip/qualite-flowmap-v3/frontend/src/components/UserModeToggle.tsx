import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

/**
 * Composant pour afficher le mode actuel et permettre le basculement Admin/Utilisateur
 * - En mode User : bouton pour entrer le mot de passe admin
 * - En mode Admin : bouton pour se déconnecter
 */
export default function UserModeToggle() {
  const { user, isAdmin, login, logout } = useAuth();
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    if (login(password)) {
      setShowPasswordModal(false);
      setPassword('');
      setError('');
    } else {
      setError('Mot de passe incorrect');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  return (
    <>
      <div className="user-mode-toggle">
        <span className={`mode-badge ${isAdmin ? 'mode-admin' : 'mode-user'}`}>
          {isAdmin ? '🔓 Admin' : '👤 Utilisateur'}
        </span>
        
        {isAdmin ? (
          <button 
            className="btn-mode-toggle btn-logout"
            onClick={logout}
            title="Revenir en mode Utilisateur"
          >
            Déconnexion
          </button>
        ) : (
          <button 
            className="btn-mode-toggle btn-login"
            onClick={() => setShowPasswordModal(true)}
            title="Passer en mode Admin"
          >
            Mode Admin
          </button>
        )}
      </div>

      {/* Modal de connexion admin */}
      {showPasswordModal && (
        <div className="modal-overlay" onClick={() => setShowPasswordModal(false)}>
          <div className="modal-content modal-small" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🔐 Connexion Admin</h3>
              <button 
                className="btn-close-modal"
                onClick={() => setShowPasswordModal(false)}
              >
                ✕
              </button>
            </div>
            <div className="modal-body">
              <p className="modal-description">
                Entrez le mot de passe administrateur pour accéder au mode édition.
              </p>
              <input
                type="password"
                placeholder="Mot de passe"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError('');
                }}
                onKeyPress={handleKeyPress}
                className={`input-password ${error ? 'input-error' : ''}`}
                autoFocus
              />
              {error && <span className="error-message">{error}</span>}
            </div>
            <div className="modal-footer">
              <button 
                className="btn-secondary"
                onClick={() => setShowPasswordModal(false)}
              >
                Annuler
              </button>
              <button 
                className="btn-primary"
                onClick={handleLogin}
              >
                Connexion
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
