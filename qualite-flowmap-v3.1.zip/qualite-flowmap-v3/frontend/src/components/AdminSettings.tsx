import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import type { RoleDefinition, MetierDefinition } from '../types';

type AdminTab = 'roles' | 'metiers' | 'cards';

/**
 * Panneau d'administration (V3.1)
 * - Gestion des rôles
 * - Gestion des métiers
 * - Gestion des cartes (ajout/suppression)
 */
export default function AdminSettings() {
  const { isAdmin } = useAuth();
  const { 
    roles, createRole, updateRole, deleteRole,
    metiers, createMetier, updateMetier, deleteMetier,
    nodes, createNode, deleteNode,
    flowData,
    isConnected
  } = useData();
  
  const [activeTab, setActiveTab] = useState<AdminTab>('roles');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  
  // États pour le formulaire
  const [formName, setFormName] = useState('');
  const [formColor, setFormColor] = useState('#3498db');
  const [formIcon, setFormIcon] = useState('📁');

  if (!isAdmin) {
    return (
      <div className="admin-settings">
        <p className="admin-locked">🔒 Mode Admin requis pour accéder à ces paramètres.</p>
      </div>
    );
  }

  // Reset du formulaire
  const resetForm = () => {
    setFormName('');
    setFormColor('#3498db');
    setFormIcon('📁');
    setEditingItem(null);
    setShowAddModal(false);
  };

  // Ouvrir le modal d'ajout
  const openAddModal = () => {
    resetForm();
    setShowAddModal(true);
  };

  // Ouvrir le modal d'édition
  const openEditModal = (item: any) => {
    setEditingItem(item);
    setFormName(item.name);
    setFormColor(item.color || '#3498db');
    setFormIcon(item.icon || '📁');
    setShowAddModal(true);
  };

  // Sauvegarder (ajout ou modification)
  const handleSave = async () => {
    if (!formName.trim()) {
      alert('Le nom est obligatoire');
      return;
    }

    try {
      if (activeTab === 'roles') {
        if (editingItem) {
          await updateRole(editingItem.id, { name: formName, color: formColor });
        } else {
          await createRole(formName, formColor);
        }
      } else if (activeTab === 'metiers') {
        if (editingItem) {
          await updateMetier(editingItem.id, { name: formName, color: formColor, icon: formIcon });
        } else {
          await createMetier(formName, formColor, formIcon);
        }
      }
      resetForm();
    } catch (err) {
      alert('Erreur lors de la sauvegarde');
    }
  };

  // Supprimer un élément
  const handleDelete = async (id: string, type: 'role' | 'metier' | 'node') => {
    const confirmMsg = type === 'node' 
      ? 'Supprimer cette carte ? Les documents associés seront aussi supprimés.'
      : `Supprimer cet élément ?`;
    
    if (!confirm(confirmMsg)) return;

    try {
      if (type === 'role') {
        await deleteRole(id);
      } else if (type === 'metier') {
        await deleteMetier(id);
      } else if (type === 'node') {
        await deleteNode(id);
      }
    } catch (err) {
      alert('Erreur lors de la suppression');
    }
  };

  // Créer une nouvelle carte
  const handleCreateCard = async () => {
    const title = prompt('Titre de la nouvelle carte :');
    if (!title?.trim()) return;

    try {
      await createNode({
        title: title.trim(),
        phaseId: 'I',
        laneId: flowData.lanes[0]?.id || 'commerce',
        shortDescription: '',
        mainRole: ''
      });
      alert('Carte créée ! Vous pouvez maintenant l\'éditer dans le flux.');
    } catch (err) {
      alert('Erreur lors de la création');
    }
  };

  return (
    <div className="admin-settings">
      <h2>⚙️ Administration</h2>
      
      {/* Onglets */}
      <div className="admin-tabs">
        <button 
          className={`admin-tab ${activeTab === 'roles' ? 'active' : ''}`}
          onClick={() => setActiveTab('roles')}
        >
          👤 Rôles ({roles.length})
        </button>
        <button 
          className={`admin-tab ${activeTab === 'metiers' ? 'active' : ''}`}
          onClick={() => setActiveTab('metiers')}
        >
          🏭 Métiers ({metiers.length})
        </button>
        <button 
          className={`admin-tab ${activeTab === 'cards' ? 'active' : ''}`}
          onClick={() => setActiveTab('cards')}
        >
          📋 Cartes ({nodes.length})
        </button>
      </div>

      {/* Contenu selon l'onglet */}
      <div className="admin-content">
        {/* === RÔLES === */}
        {activeTab === 'roles' && (
          <div className="admin-section">
            <div className="section-header">
              <h3>Liste des rôles</h3>
              <button 
                className="btn-add"
                onClick={openAddModal}
                disabled={!isConnected}
              >
                + Ajouter un rôle
              </button>
            </div>
            
            <p className="section-hint">
              Les rôles sont utilisés dans les champs "Responsabilités" des cartes.
            </p>
            
            {roles.length === 0 ? (
              <p className="no-items">Aucun rôle défini.</p>
            ) : (
              <div className="items-list">
                {roles.map(role => (
                  <div key={role.id} className="list-item">
                    <span 
                      className="item-color-dot"
                      style={{ backgroundColor: role.color }}
                    />
                    <span className="item-name">{role.name}</span>
                    <div className="item-actions">
                      <button 
                        className="btn-edit-item"
                        onClick={() => openEditModal(role)}
                      >
                        ✏️
                      </button>
                      <button 
                        className="btn-delete-item"
                        onClick={() => handleDelete(role.id, 'role')}
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* === MÉTIERS === */}
        {activeTab === 'metiers' && (
          <div className="admin-section">
            <div className="section-header">
              <h3>Liste des métiers</h3>
              <button 
                className="btn-add"
                onClick={openAddModal}
                disabled={!isConnected}
              >
                + Ajouter un métier
              </button>
            </div>
            
            <p className="section-hint">
              Les métiers correspondent aux colonnes du flux (Commerce, Calcul, etc.).
            </p>
            
            {metiers.length === 0 ? (
              <p className="no-items">Aucun métier défini.</p>
            ) : (
              <div className="items-list">
                {metiers.map(metier => (
                  <div key={metier.id} className="list-item">
                    <span className="item-icon">{metier.icon}</span>
                    <span 
                      className="item-color-dot"
                      style={{ backgroundColor: metier.color }}
                    />
                    <span className="item-name">{metier.name}</span>
                    <div className="item-actions">
                      <button 
                        className="btn-edit-item"
                        onClick={() => openEditModal(metier)}
                      >
                        ✏️
                      </button>
                      <button 
                        className="btn-delete-item"
                        onClick={() => handleDelete(metier.id, 'metier')}
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* === CARTES === */}
        {activeTab === 'cards' && (
          <div className="admin-section">
            <div className="section-header">
              <h3>Liste des cartes d'action</h3>
              <button 
                className="btn-add"
                onClick={handleCreateCard}
                disabled={!isConnected}
              >
                + Ajouter une carte
              </button>
            </div>
            
            <p className="section-hint">
              Les cartes représentent les étapes du flux. Cliquez sur une carte dans le flux pour l'éditer.
            </p>
            
            {nodes.length === 0 ? (
              <p className="no-items">Aucune carte définie.</p>
            ) : (
              <div className="items-list cards-list">
                {nodes.map((node, index) => {
                  const phase = flowData.phases.find(p => p.id === node.phaseId);
                  const lane = flowData.lanes.find(l => l.id === node.laneId);
                  
                  return (
                    <div key={node.id} className="list-item card-item">
                      <span className="card-order">#{index + 1}</span>
                      <div className="card-info">
                        <span className="card-title">{node.title}</span>
                        <span className="card-location">
                          Phase {phase?.id || '?'} • {lane?.name || '?'}
                        </span>
                      </div>
                      <div className="item-actions">
                        <button 
                          className="btn-delete-item"
                          onClick={() => handleDelete(node.id, 'node')}
                          title="Supprimer cette carte"
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modal d'ajout/édition pour rôles et métiers */}
      {showAddModal && activeTab !== 'cards' && (
        <div className="modal-overlay" onClick={resetForm}>
          <div className="modal-content modal-small" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>
                {editingItem ? '✏️ Modifier' : '➕ Ajouter'} 
                {activeTab === 'roles' ? ' un rôle' : ' un métier'}
              </h3>
              <button className="btn-close-modal" onClick={resetForm}>✕</button>
            </div>
            
            <div className="modal-body">
              <div className="form-group">
                <label>Nom *</label>
                <input
                  type="text"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder={activeTab === 'roles' ? 'Ex: ADV' : 'Ex: Commerce'}
                  autoFocus
                />
              </div>
              
              <div className="form-group">
                <label>Couleur</label>
                <input
                  type="color"
                  value={formColor}
                  onChange={e => setFormColor(e.target.value)}
                />
              </div>
              
              {activeTab === 'metiers' && (
                <div className="form-group">
                  <label>Icône (emoji)</label>
                  <input
                    type="text"
                    value={formIcon}
                    onChange={e => setFormIcon(e.target.value)}
                    placeholder="Ex: 💼"
                    maxLength={4}
                  />
                </div>
              )}
            </div>
            
            <div className="modal-footer">
              <button className="btn-secondary" onClick={resetForm}>
                Annuler
              </button>
              <button className="btn-primary" onClick={handleSave}>
                {editingItem ? 'Enregistrer' : 'Ajouter'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
