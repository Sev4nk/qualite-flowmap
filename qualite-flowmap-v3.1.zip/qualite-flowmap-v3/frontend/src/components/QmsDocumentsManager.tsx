import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData, QmsDocumentWithFile, getDocumentDownloadUrl } from '../context/DataContext';
import type { QmsDocument } from '../types';

interface QmsDocumentsManagerProps {
  nodeId: string;
  documents: QmsDocumentWithFile[];
}

/**
 * Gestionnaire de documents QMS
 * - Mode User : consultation et téléchargement uniquement
 * - Mode Admin : ajout, modification, suppression de documents
 * 
 * Les fichiers sont stockés sur le serveur backend.
 */
export default function QmsDocumentsManager({ nodeId, documents }: QmsDocumentsManagerProps) {
  const { isAdmin } = useAuth();
  const { addDocument, updateDocument, deleteDocument, isConnected } = useData();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // État pour le formulaire d'ajout/modification
  const [formData, setFormData] = useState<Partial<QmsDocumentWithFile>>({
    code: '',
    title: '',
    type: 'PROC',
    comment: ''
  });

  // Type de document -> badge coloré
  const getDocTypeBadge = (type: QmsDocument['type']) => {
    const badges: Record<string, { label: string; class: string }> = {
      'PROC': { label: 'Procédure', class: 'badge-proc' },
      'FORM': { label: 'Formulaire', class: 'badge-form' },
      'CHECKLIST': { label: 'Checklist', class: 'badge-checklist' },
      'IT': { label: 'Instruction', class: 'badge-it' },
      'TEMPLATE': { label: 'Template', class: 'badge-template' },
      'OTHER': { label: 'Autre', class: 'badge-other' }
    };
    return badges[type] || badges['OTHER'];
  };

  // Télécharger un document
  const handleDownload = (doc: QmsDocumentWithFile) => {
    if (doc.storedFileName) {
      // Télécharger depuis le serveur
      const url = getDocumentDownloadUrl(doc.storedFileName);
      window.open(url, '_blank');
    } else if (doc.url) {
      // Ouvrir l'URL externe
      window.open(doc.url, '_blank');
    } else {
      alert('Aucun fichier attaché à ce document.');
    }
  };

  // Gérer la sélection de fichier
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Vérifier la taille (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        alert('Le fichier est trop volumineux (max 10 Mo)');
        return;
      }
      setSelectedFile(file);
    }
  };

  // Ouvrir le modal d'ajout
  const openAddModal = () => {
    setFormData({
      code: '',
      title: '',
      type: 'PROC',
      comment: '',
      url: ''
    });
    setSelectedFile(null);
    setEditingIndex(null);
    setShowAddModal(true);
  };

  // Ouvrir le modal d'édition
  const openEditModal = (index: number) => {
    const doc = documents[index];
    setFormData({
      code: doc.code,
      title: doc.title,
      type: doc.type,
      comment: doc.comment || '',
      url: doc.url || '',
      fileName: doc.fileName,
      storedFileName: doc.storedFileName
    });
    setSelectedFile(null);
    setEditingIndex(index);
    setShowAddModal(true);
  };

  // Sauvegarder (ajout ou modification)
  const handleSave = async () => {
    if (!formData.code || !formData.title) {
      alert('Le code et le titre sont obligatoires');
      return;
    }

    if (!isConnected) {
      alert('Impossible de sauvegarder : serveur non connecté');
      return;
    }

    setIsSubmitting(true);

    try {
      const docData: Partial<QmsDocumentWithFile> = {
        code: formData.code!,
        title: formData.title!,
        type: formData.type as QmsDocument['type'],
        comment: formData.comment || undefined,
        url: formData.url || undefined
      };

      if (editingIndex !== null) {
        await updateDocument(nodeId, editingIndex, docData, selectedFile || undefined);
      } else {
        await addDocument(nodeId, docData, selectedFile || undefined);
      }

      setShowAddModal(false);
      setFormData({});
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err) {
      alert('Erreur lors de la sauvegarde : ' + (err instanceof Error ? err.message : 'Erreur inconnue'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Supprimer un document
  const handleDelete = async (index: number) => {
    if (!isConnected) {
      alert('Impossible de supprimer : serveur non connecté');
      return;
    }

    if (confirm('Êtes-vous sûr de vouloir supprimer ce document ?')) {
      try {
        await deleteDocument(nodeId, index);
      } catch (err) {
        alert('Erreur lors de la suppression : ' + (err instanceof Error ? err.message : 'Erreur inconnue'));
      }
    }
  };

  return (
    <div className="qms-documents-manager">
      {/* En-tête avec bouton d'ajout (admin uniquement) */}
      <div className="docs-header">
        <h3>📄 Documents QMS</h3>
        {isAdmin && isConnected && (
          <button className="btn-add-doc" onClick={openAddModal}>
            + Ajouter
          </button>
        )}
      </div>

      {/* Message si non connecté */}
      {!isConnected && isAdmin && (
        <p className="connection-warning">⚠️ Serveur non connecté - modifications désactivées</p>
      )}

      {/* Liste des documents */}
      {documents.length > 0 ? (
        <div className="docs-list">
          {documents.map((doc, index) => {
            const badge = getDocTypeBadge(doc.type);
            const hasFile = !!(doc.storedFileName || doc.url);

            return (
              <div key={index} className="doc-item">
                <span className={`doc-badge ${badge.class}`}>{badge.label}</span>
                
                <div className="doc-info">
                  <span className="doc-code">{doc.code}</span>
                  <span className="doc-title">{doc.title}</span>
                  {doc.comment && (
                    <span className="doc-comment">{doc.comment}</span>
                  )}
                  {doc.fileName && (
                    <span className="doc-filename">📎 {doc.fileName}</span>
                  )}
                </div>

                <div className="doc-actions">
                  {/* Télécharger (tous les modes) */}
                  {hasFile && (
                    <button 
                      className="btn-doc-action btn-download"
                      onClick={() => handleDownload(doc)}
                      title="Télécharger"
                    >
                      ⬇️
                    </button>
                  )}

                  {/* Actions admin uniquement */}
                  {isAdmin && isConnected && (
                    <>
                      <button 
                        className="btn-doc-action btn-edit"
                        onClick={() => openEditModal(index)}
                        title="Modifier"
                      >
                        ✏️
                      </button>
                      <button 
                        className="btn-doc-action btn-delete"
                        onClick={() => handleDelete(index)}
                        title="Supprimer"
                      >
                        🗑️
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="no-docs">Aucun document QMS pour cette étape.</p>
      )}

      {/* Modal d'ajout/modification */}
      {showAddModal && (
        <div className="modal-overlay" onClick={() => !isSubmitting && setShowAddModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{editingIndex !== null ? '✏️ Modifier le document' : '➕ Ajouter un document QMS'}</h3>
              <button 
                className="btn-close-modal" 
                onClick={() => !isSubmitting && setShowAddModal(false)}
                disabled={isSubmitting}
              >
                ✕
              </button>
            </div>
            
            <div className="modal-body">
              <div className="form-group">
                <label htmlFor="doc-code">Code *</label>
                <input
                  id="doc-code"
                  type="text"
                  placeholder="Ex: PROC-001"
                  value={formData.code || ''}
                  onChange={e => setFormData(prev => ({ ...prev, code: e.target.value }))}
                  disabled={isSubmitting}
                />
              </div>

              <div className="form-group">
                <label htmlFor="doc-title">Titre *</label>
                <input
                  id="doc-title"
                  type="text"
                  placeholder="Ex: Procédure de contrôle"
                  value={formData.title || ''}
                  onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  disabled={isSubmitting}
                />
              </div>

              <div className="form-group">
                <label htmlFor="doc-type">Type</label>
                <select
                  id="doc-type"
                  value={formData.type || 'PROC'}
                  onChange={e => setFormData(prev => ({ ...prev, type: e.target.value as QmsDocument['type'] }))}
                  disabled={isSubmitting}
                >
                  <option value="PROC">Procédure</option>
                  <option value="FORM">Formulaire</option>
                  <option value="CHECKLIST">Checklist</option>
                  <option value="IT">Instruction de travail</option>
                  <option value="TEMPLATE">Template</option>
                  <option value="OTHER">Autre</option>
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="doc-comment">Commentaire</label>
                <input
                  id="doc-comment"
                  type="text"
                  placeholder="Commentaire optionnel"
                  value={formData.comment || ''}
                  onChange={e => setFormData(prev => ({ ...prev, comment: e.target.value }))}
                  disabled={isSubmitting}
                />
              </div>

              <div className="form-group">
                <label htmlFor="doc-url">URL externe (optionnel)</label>
                <input
                  id="doc-url"
                  type="url"
                  placeholder="https://..."
                  value={formData.url || ''}
                  onChange={e => setFormData(prev => ({ ...prev, url: e.target.value }))}
                  disabled={isSubmitting}
                />
              </div>

              <div className="form-group">
                <label htmlFor="doc-file">Fichier à attacher (max 10 Mo)</label>
                <input
                  ref={fileInputRef}
                  id="doc-file"
                  type="file"
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
                  onChange={handleFileChange}
                  disabled={isSubmitting}
                />
                {selectedFile && (
                  <span className="file-attached">📎 Nouveau : {selectedFile.name}</span>
                )}
                {!selectedFile && formData.fileName && (
                  <span className="file-attached">📎 Actuel : {formData.fileName}</span>
                )}
              </div>
            </div>

            <div className="modal-footer">
              <button 
                className="btn-secondary" 
                onClick={() => setShowAddModal(false)}
                disabled={isSubmitting}
              >
                Annuler
              </button>
              <button 
                className="btn-primary" 
                onClick={handleSave}
                disabled={isSubmitting}
              >
                {isSubmitting ? '⏳ Envoi...' : (editingIndex !== null ? 'Enregistrer' : 'Ajouter')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
