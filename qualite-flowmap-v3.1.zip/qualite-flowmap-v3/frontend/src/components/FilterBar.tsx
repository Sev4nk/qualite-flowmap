import React from 'react';
import type { Phase, Lane, FilterState } from '../types';

interface FilterBarProps {
  phases: Phase[];
  lanes: Lane[];
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  roles: string[];
}

/**
 * Barre de filtres permettant de filtrer les étapes par :
 * - Phase (I à IX)
 * - Colonne métier (Commerce, Calcul, etc.)
 * - Rôle principal
 * - Recherche textuelle
 */
export default function FilterBar({ 
  phases, 
  lanes, 
  filters, 
  onFilterChange,
  roles 
}: FilterBarProps) {
  
  const handlePhaseChange = (phaseId: string | null) => {
    onFilterChange({ ...filters, phaseId });
  };

  const handleLaneChange = (laneId: string | null) => {
    onFilterChange({ ...filters, laneId });
  };

  const handleRoleChange = (role: string | null) => {
    onFilterChange({ ...filters, role });
  };

  const handleSearchChange = (search: string) => {
    onFilterChange({ ...filters, search });
  };

  const clearFilters = () => {
    onFilterChange({
      phaseId: null,
      laneId: null,
      role: null,
      search: ''
    });
  };

  const hasActiveFilters = filters.phaseId || filters.laneId || filters.role || filters.search;

  return (
    <div className="filter-bar">
      <div className="filter-group">
        <label htmlFor="phase-filter">Phase :</label>
        <select 
          id="phase-filter"
          value={filters.phaseId || ''} 
          onChange={(e) => handlePhaseChange(e.target.value || null)}
        >
          <option value="">Toutes les phases</option>
          {phases.map(phase => (
            <option key={phase.id} value={phase.id}>
              {phase.id} – {phase.name}
            </option>
          ))}
        </select>
      </div>

      <div className="filter-group">
        <label htmlFor="lane-filter">Métier :</label>
        <select 
          id="lane-filter"
          value={filters.laneId || ''} 
          onChange={(e) => handleLaneChange(e.target.value || null)}
        >
          <option value="">Tous les métiers</option>
          {lanes.map(lane => (
            <option key={lane.id} value={lane.id}>
              {lane.icon} {lane.name}
            </option>
          ))}
        </select>
      </div>

      <div className="filter-group">
        <label htmlFor="role-filter">Rôle :</label>
        <select 
          id="role-filter"
          value={filters.role || ''} 
          onChange={(e) => handleRoleChange(e.target.value || null)}
        >
          <option value="">Tous les rôles</option>
          {roles.map(role => (
            <option key={role} value={role}>{role}</option>
          ))}
        </select>
      </div>

      <div className="filter-group filter-search">
        <label htmlFor="search-filter">🔍</label>
        <input
          id="search-filter"
          type="text"
          placeholder="Rechercher une étape..."
          value={filters.search}
          onChange={(e) => handleSearchChange(e.target.value)}
        />
      </div>

      {hasActiveFilters && (
        <button className="btn-clear-filters" onClick={clearFilters}>
          ✕ Effacer les filtres
        </button>
      )}
    </div>
  );
}
