import React from 'react';
import type { Lane, StepStatus } from '../types';
import { NodeWithFiles } from '../context/DataContext';

interface NodeCardProps {
  node: NodeWithFiles;
  lane: Lane;
  isHighlighted: boolean;
  isDimmed: boolean;
  onClick: () => void;
  /** V3.1 - Statut de l'étape dans le projet sélectionné */
  stepStatus?: StepStatus;
}

/**
 * Carte représentant une étape du flux dans la grille.
 * V3.1 : Affichage du statut (locked/active/done) si un projet est sélectionné.
 */
export default function NodeCard({ 
  node, 
  lane, 
  isHighlighted, 
  isDimmed,
  onClick,
  stepStatus
}: NodeCardProps) {
  
  // Déterminer le style selon le type de nœud
  const getNodeTypeClass = () => {
    switch (node.nodeType) {
      case 'start': return 'node-start';
      case 'end': return 'node-end';
      case 'decision': return 'node-decision';
      case 'wait': return 'node-wait';
      case 'subprocess': return 'node-subprocess';
      default: return 'node-standard';
    }
  };

  // V3.1 - Classe selon le statut du projet
  const getStatusClass = () => {
    if (!stepStatus) return '';
    return `step-${stepStatus}`; // step-locked, step-active, step-done
  };

  // Icône selon le type
  const getNodeIcon = () => {
    switch (node.nodeType) {
      case 'start': return '▶';
      case 'end': return '✓';
      case 'decision': return '◇';
      case 'wait': return '⏳';
      case 'subprocess': return '↩';
      default: return '';
    }
  };

  // V3.1 - Indicateur de statut
  const getStatusIndicator = () => {
    if (!stepStatus) return null;
    switch (stepStatus) {
      case 'locked': return <span className="status-indicator locked" title="Verrouillée">🔒</span>;
      case 'active': return <span className="status-indicator active" title="Active">▶️</span>;
      case 'done': return <span className="status-indicator done" title="Terminée">✅</span>;
      default: return null;
    }
  };

  // Nombre de documents QMS
  const docCount = node.qmsDocuments?.length || 0;
  
  // Nombre de documents avec fichier attaché
  const fileCount = node.qmsDocuments?.filter(d => d.storedFileName || d.url).length || 0;

  return (
    <div 
      className={`node-card ${getNodeTypeClass()} ${getStatusClass()} ${isHighlighted ? 'highlighted' : ''} ${isDimmed ? 'dimmed' : ''}`}
      onClick={onClick}
      style={{ 
        borderLeftColor: lane.color,
        '--lane-color': lane.color 
      } as React.CSSProperties}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && onClick()}
    >
      <div className="node-header">
        {getStatusIndicator()}
        <span className="node-type-icon">{getNodeIcon()}</span>
        <span className="node-id">{node.id}</span>
      </div>
      
      <h4 className="node-title">{node.title}</h4>
      
      <div className="node-footer">
        <span className="node-role" title={`Rôle principal: ${node.mainRole}`}>
          👤 {node.mainRole && node.mainRole.length > 15 ? node.mainRole.substring(0, 15) + '…' : (node.mainRole || '–')}
        </span>
        {docCount > 0 && (
          <span className="node-docs" title={`${docCount} document(s) QMS${fileCount > 0 ? ` dont ${fileCount} avec fichier` : ''}`}>
            📄 {docCount}
            {fileCount > 0 && <span className="file-indicator">📎</span>}
          </span>
        )}
      </div>
    </div>
  );
}
