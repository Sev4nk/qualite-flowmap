import React from 'react';
import type { Phase, Lane, FilterState, Project, StepStatus } from '../types';
import { NodeWithFiles } from '../context/DataContext';
import NodeCard from './NodeCard';

interface FlowMapProps {
  phases: Phase[];
  lanes: Lane[];
  nodes: NodeWithFiles[];
  filters: FilterState;
  onNodeClick: (node: NodeWithFiles) => void;
  /** V3.1 - Projet sélectionné (optionnel) */
  selectedProject?: Project | null;
}

/**
 * Grille principale affichant le flux de fabrication.
 * V3.1 : Affichage du statut des étapes si un projet est sélectionné.
 */
export default function FlowMap({ 
  phases, 
  lanes, 
  nodes, 
  filters,
  onNodeClick,
  selectedProject
}: FlowMapProps) {

  // V3.1 - Obtenir le statut d'un nœud dans le projet sélectionné
  const getStepStatus = (nodeId: string): StepStatus | undefined => {
    if (!selectedProject) return undefined;
    const step = selectedProject.steps.find(s => s.nodeId === nodeId);
    return step?.status;
  };

  // Filtrer et organiser les nœuds
  const getNodesForCell = (phaseId: string, laneId: string): NodeWithFiles[] => {
    return nodes
      .filter(node => node.phaseId === phaseId && node.laneId === laneId)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  };

  // Vérifier si un nœud passe les filtres
  const nodePassesFilters = (node: NodeWithFiles): boolean => {
    // Filtre par phase
    if (filters.phaseId && node.phaseId !== filters.phaseId) {
      return false;
    }
    // Filtre par lane
    if (filters.laneId && node.laneId !== filters.laneId) {
      return false;
    }
    // Filtre par rôle
    if (filters.role) {
      const hasRole = 
        node.mainRole === filters.role || 
        node.secondaryRoles?.includes(filters.role);
      if (!hasRole) return false;
    }
    // Filtre par recherche textuelle
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      const matches = 
        node.title.toLowerCase().includes(searchLower) ||
        node.shortDescription.toLowerCase().includes(searchLower) ||
        node.id.toLowerCase().includes(searchLower) ||
        (node.mainRole && node.mainRole.toLowerCase().includes(searchLower));
      if (!matches) return false;
    }
    return true;
  };

  // Vérifier si des filtres sont actifs
  const hasActiveFilters = !!(filters.phaseId || filters.laneId || filters.role || filters.search);

  return (
    <div className="flowmap-container">
      {/* Header avec les colonnes métiers */}
      <div className="flowmap-header">
        <div className="header-phases">
          <span>Phases</span>
        </div>
        {lanes.map(lane => (
          <div 
            key={lane.id} 
            className={`header-lane ${filters.laneId === lane.id ? 'active' : ''}`}
            style={{ backgroundColor: lane.color }}
          >
            <span className="lane-icon">{lane.icon}</span>
            <span className="lane-name">{lane.name}</span>
          </div>
        ))}
      </div>

      {/* Corps de la grille */}
      <div className="flowmap-body">
        {phases.map(phase => (
          <div 
            key={phase.id} 
            className={`flowmap-row ${filters.phaseId === phase.id ? 'active' : ''}`}
          >
            {/* En-tête de la phase (colonne gauche) */}
            <div 
              className="row-phase"
              style={{ backgroundColor: phase.color }}
            >
              <span className="phase-id">{phase.id}</span>
              <span className="phase-name">{phase.name}</span>
            </div>

            {/* Cellules pour chaque lane */}
            {lanes.map(lane => {
              const cellNodes = getNodesForCell(phase.id, lane.id);
              const isCellHighlighted = 
                (filters.phaseId === phase.id) || 
                (filters.laneId === lane.id);

              return (
                <div 
                  key={`${phase.id}-${lane.id}`} 
                  className={`flowmap-cell ${isCellHighlighted && hasActiveFilters ? 'cell-highlighted' : ''}`}
                >
                  {cellNodes.length > 0 ? (
                    <div className="cell-nodes">
                      {cellNodes.map(node => {
                        const passes = nodePassesFilters(node);
                        const stepStatus = getStepStatus(node.id);
                        
                        return (
                          <NodeCard
                            key={node.id}
                            node={node}
                            lane={lane}
                            isHighlighted={hasActiveFilters && passes}
                            isDimmed={hasActiveFilters && !passes}
                            onClick={() => onNodeClick(node)}
                            stepStatus={stepStatus}
                          />
                        );
                      })}
                    </div>
                  ) : (
                    <div className="cell-empty">–</div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
