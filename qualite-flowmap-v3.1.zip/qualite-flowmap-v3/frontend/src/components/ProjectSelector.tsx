import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import type { Project } from '../types';

/**
 * Sélecteur de projet simple
 * - Affiche la liste des projets existants
 * - Permet de créer un nouveau projet (mode User et Admin)
 * - Permet de supprimer un projet (mode Admin uniquement)
 */
export default function ProjectSelector() {
  const { isAdmin } = useAuth();
  const { 
    projects, 
    selectedProject, 
    selectProject, 
    createProject, 
    deleteProject,
    nodes,
    isConnected 
  } = useData();
  
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [affaireNumber, setAffaireNumber] = useState('');
  const [chantierName, setChantierName] = useState('');
  const [creating, setCreating] = useState(false);

  // Créer un nouveau projet
  const handleCreate = async () => {
    if (!affaireNumber.trim() || !chantierName.trim()) {
      alert('Veuillez remplir tous les champs');
      return;
    }
    
    setCreating(true);
    try {
      await createProject(affaireNumber.trim(), chantierName.trim());
      setShowCreateModal(false);
      setAffaireNumber('');
      setChantierName('');
    } catch (err) {
      alert('Erreur lors de la création du projet');
    } finally {
      setCreating(false);
    }
  };

  // Supprimer un projet
  const handleDelete = async (project: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(`Supprimer le projet "${project.affaireNumber} - ${project.chantierName}" ?`)) {
      try {
        await deleteProject(project.id);
      } catch (err) {
        alert('Erreur lors de la suppression');
      }
    }
  };

  // Calculer la progression d'un projet
  const getProgress = (project: Project) => {
    const done = project.steps.filter(s => s.status === 'done').length;
    const total = project.steps.length;
    return { done, total, percent: total > 0 ? Math.round((done / total) * 100) : 0 };
  };

  return (
    <div className="project-selector">
      {/* En-tête avec bouton nouveau projet */}
      <div className="project-selector-header">
        <h3>📁 Projets</h3>
        <button 
          className="btn-add-project"
          onClick={() => setShowCreateModal(true)}
          disabled={!isConnected}
          title={!isConnected ? 'Serveur non connecté' : 'Créer un nouveau projet'}
        >
          + Nouveau projet
        </button>
      </div>

      {/* Liste des projets */}
      {projects.length === 0 ? (
        <div className="no-projects">
          <p>Aucun projet pour le moment.</p>
          <p className="hint">Créez un projet pour suivre la progression du flux.</p>
        </div>
      ) : (
        <div className="projects-list">
          {projects.map(project => {
            const progress = getProgress(project);
            const isSelected = selectedProject?.id === project.id;
            
            return (
              <div 
                key={project.id}
                className={`project-item ${isSelected ? 'selected' : ''}`}
                onClick={() => selectProject(isSelected ? null : project)}
              >
                <div className="project-info">
                  <span className="project-affaire">{project.affaireNumber}</span>
                  <span className="project-chantier">{project.chantierName}</span>
                </div>
                
                <div className="project-progress">
                  <div className="progress-bar">
                    <div 
                      className="progress-fill"
                      style={{ width: `${progress.percent}%` }}
                    />
                  </div>
                  <span className="progress-text">
                    {progress.done}/{progress.total} ({progress.percent}%)
                  </span>
                </div>
                
                <div className="project-actions">
                  {isSelected && (
                    <span className="selected-badge">✓ Sélectionné</span>
                  )}
                  {isAdmin && (
                    <button 
                      className="btn-delete-project"
                      onClick={(e) => handleDelete(project, e)}
                      title="Supprimer ce projet"
                    >
                      🗑️
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Info sur le projet sélectionné */}
      {selectedProject && (
        <div className="selected-project-info">
          <p>
            <strong>Projet actif :</strong> {selectedProject.affaireNumber} - {selectedProject.chantierName}
          </p>
          <button 
            className="btn-deselect"
            onClick={() => selectProject(null)}
          >
            ✕ Désélectionner
          </button>
        </div>
      )}

      {/* Modal de création */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={() => setShowCreateModal(false)}>
          <div className="modal-content modal-small" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>➕ Nouveau projet</h3>
              <button 
                className="btn-close-modal"
                onClick={() => setShowCreateModal(false)}
              >
                ✕
              </button>
            </div>
            
            <div className="modal-body">
              <div className="form-group">
                <label htmlFor="affaire-number">N° d'affaire *</label>
                <input
                  id="affaire-number"
                  type="text"
                  placeholder="Ex: AF-L2305001"
                  value={affaireNumber}
                  onChange={e => setAffaireNumber(e.target.value)}
                  autoFocus
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="chantier-name">Nom du chantier *</label>
                <input
                  id="chantier-name"
                  type="text"
                  placeholder="Ex: Réservoir XXX"
                  value={chantierName}
                  onChange={e => setChantierName(e.target.value)}
                />
              </div>
              
              <p className="info-text">
                ℹ️ Le projet sera initialisé avec {nodes.length} étapes basées sur le flux actuel.
              </p>
            </div>
            
            <div className="modal-footer">
              <button 
                className="btn-secondary"
                onClick={() => setShowCreateModal(false)}
              >
                Annuler
              </button>
              <button 
                className="btn-primary"
                onClick={handleCreate}
                disabled={creating}
              >
                {creating ? '⏳ Création...' : 'Créer le projet'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
