/**
 * Types pour l'application QUALITE Flowmap
 * 
 * Structure du modèle de données :
 * - Phase : les 9 phases génériques du flux (I à IX)
 * - Lane : les colonnes métiers (Commerce, Calcul, Étude, etc.)
 * - Node : chaque étape/case du flowchart
 * - QmsDocument : document qualité associé à une étape
 */

/**
 * Document QMS (Qualité Management System)
 * Représente un document qualité à utiliser à une étape donnée
 */
export interface QmsDocument {
  /** Code du document (ex: "PROC-001", "FORM-123") */
  code: string;
  /** Titre du document */
  title: string;
  /** Type de document */
  type: 'PROC' | 'FORM' | 'CHECKLIST' | 'IT' | 'TEMPLATE' | 'OTHER';
  /** Commentaire optionnel sur l'utilisation */
  comment?: string;
  /** URL vers le document (optionnel) */
  url?: string;
}

/**
 * Phase générique du flux (I à IX)
 */
export interface Phase {
  /** Identifiant unique (ex: "I", "II", "III") */
  id: string;
  /** Numéro de la phase (1-9) */
  order: number;
  /** Nom de la phase (ex: "COMMANDE", "CALCUL") */
  name: string;
  /** Couleur associée à la phase (optionnel) */
  color?: string;
}

/**
 * Colonne métier (lane)
 */
export interface Lane {
  /** Identifiant unique (ex: "commerce", "calcul") */
  id: string;
  /** Ordre d'affichage (1-9) */
  order: number;
  /** Nom affiché (ex: "Commerce", "Calcul") */
  name: string;
  /** Couleur associée à la colonne */
  color: string;
  /** Icône (emoji ou code) */
  icon?: string;
}

/**
 * Nœud du flowchart (étape)
 */
export interface Node {
  /** Identifiant unique */
  id: string;
  /** Titre court de l'étape */
  title: string;
  /** Référence à la phase (id de Phase) */
  phaseId: string;
  /** Référence à la colonne métier (id de Lane) */
  laneId: string;
  /** Ordre dans la cellule (si plusieurs nœuds dans la même case) */
  order?: number;
  /** Description courte de l'objectif */
  shortDescription: string;
  /** Rôle principal responsable */
  mainRole: string;
  /** Rôles secondaires (info, support) */
  secondaryRoles?: string[];
  /** Documents QMS à utiliser */
  qmsDocuments?: QmsDocument[];
  /** Conditions GO/NO GO pour passer à l'étape suivante */
  conditions?: string[];
  /** Notes libres (rappels Qualité, FM, etc.) */
  notes?: string;
  /** Type de nœud pour le style */
  nodeType?: 'standard' | 'decision' | 'start' | 'end' | 'wait' | 'subprocess';
  /** Étapes suivantes (ids) - pour tracer les liens */
  nextNodes?: string[];
}

/**
 * Configuration complète du flux
 */
export interface FlowConfig {
  /** Métadonnées du flux */
  metadata: {
    title: string;
    version: string;
    lastUpdate: string;
    author?: string;
    description?: string;
  };
  /** Liste des phases */
  phases: Phase[];
  /** Liste des colonnes métiers */
  lanes: Lane[];
  /** Liste des nœuds/étapes */
  nodes: Node[];
}

/**
 * État des filtres
 */
export interface FilterState {
  /** Phase sélectionnée (null = toutes) */
  phaseId: string | null;
  /** Colonne sélectionnée (null = toutes) */
  laneId: string | null;
  /** Rôle sélectionné (null = tous) */
  role: string | null;
  /** Recherche textuelle */
  search: string;
}

// ============================================
// V3.1 - RÔLES ET MÉTIERS PARAMÉTRABLES
// ============================================

/**
 * Définition d'un rôle (ex: ADV, Achats, Commerce)
 * Les rôles sont paramétrables en mode Admin
 */
export interface RoleDefinition {
  id: string;
  name: string;
  color?: string;
}

/**
 * Définition d'un métier/service (ex: Commerce, Calcul, Étude)
 * Les métiers sont paramétrables en mode Admin
 */
export interface MetierDefinition {
  id: string;
  name: string;
  color: string;
  icon?: string;
  order: number;
}

// ============================================
// V3.1 - GESTION DES PROJETS
// ============================================

/**
 * Statut d'une étape dans un projet
 */
export type StepStatus = 'locked' | 'active' | 'done';

/**
 * Étape d'un projet (référence une carte/node)
 */
export interface ProjectStep {
  /** Référence à la carte (id du Node) */
  nodeId: string;
  /** Statut de l'étape */
  status: StepStatus;
  /** Date de complétion (si done) */
  completedAt?: string;
  /** Commentaire optionnel */
  comment?: string;
}

/**
 * Projet avec progression par étapes
 */
export interface Project {
  id: string;
  /** Numéro d'affaire (ex: "AF-L2305001") */
  affaireNumber: string;
  /** Nom du chantier */
  chantierName: string;
  /** Date de création */
  createdAt: string;
  /** Date de dernière mise à jour */
  updatedAt?: string;
  /** Étapes du projet (progression) */
  steps: ProjectStep[];
  /** Projet archivé ? */
  archived?: boolean;
}
