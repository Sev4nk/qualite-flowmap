import React, { useState, useMemo } from 'react';
import type { FilterState, StepStatus } from './types';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider, useData, NodeWithFiles } from './context/DataContext';
import FilterBar from './components/FilterBar';
import FlowMap from './components/FlowMap';
import StepPanel from './components/StepPanel';
import UserModeToggle from './components/UserModeToggle';
import ArchitectureViewer from './components/ArchitectureViewer';
import ProjectSelector from './components/ProjectSelector';
import AdminSettings from './components/AdminSettings';
import './App.css';

type TabType = 'flowmap' | 'architecture' | 'admin';

/**
 * Contenu principal de l'application
 * V3.1 : Ajout du ProjectSelector et AdminSettings
 */
function AppContent() {
  const { isAdmin } = useAuth();
  const { 
    flowData, 
    nodes, 
    resetToDefaults, 
    exportData, 
    importData,
    isLoading,
    error,
    isConnected,
    refreshData,
    // V3.1 - Projets
    selectedProject,
    advanceProjectStep
  } = useData();
  
  // Onglet actif
  const [activeTab, setActiveTab] = useState<TabType>('flowmap');
  
  // État du nœud sélectionné (pour le panneau de détail)
  const [selectedNode, setSelectedNode] = useState<NodeWithFiles | null>(null);

  // État des filtres
  const [filters, setFilters] = useState<FilterState>({
    phaseId: null,
    laneId: null,
    role: null,
    search: ''
  });

  // Données du flux
  const { metadata, phases, lanes } = flowData;

  // Extraire la liste unique des rôles (pour le filtre)
  const roles = useMemo(() => {
    const roleSet = new Set<string>();
    nodes.forEach(node => {
      if (node.mainRole) roleSet.add(node.mainRole);
      node.secondaryRoles?.forEach(role => roleSet.add(role));
    });
    return Array.from(roleSet).sort();
  }, [nodes]);

  // Trouver la phase et la lane du nœud sélectionné
  const selectedPhase = selectedNode 
    ? phases.find(p => p.id === selectedNode.phaseId) || null 
    : null;
  
  const selectedLane = selectedNode 
    ? lanes.find(l => l.id === selectedNode.laneId) || null 
    : null;

  // V3.1 - Obtenir le statut de l'étape pour le nœud sélectionné
  const getSelectedNodeStatus = (): StepStatus | undefined => {
    if (!selectedProject || !selectedNode) return undefined;
    const step = selectedProject.steps.find(s => s.nodeId === selectedNode.id);
    return step?.status;
  };

  // V3.1 - Valider l'étape active
  const handleValidateStep = async () => {
    if (!selectedProject) return;
    
    try {
      await advanceProjectStep(selectedProject.id);
      // Fermer le panneau pour forcer le rafraîchissement
      setSelectedNode(null);
    } catch (err) {
      alert('Erreur lors de la validation de l\'étape');
    }
  };

  // Handlers
  const handleNodeClick = (node: NodeWithFiles) => {
    // Récupérer la version à jour du nœud depuis les données
    const updatedNode = nodes.find(n => n.id === node.id) || node;
    setSelectedNode(updatedNode);
  };

  const handleClosePanel = () => {
    setSelectedNode(null);
  };

  const handleFilterChange = (newFilters: FilterState) => {
    setFilters(newFilters);
  };

  // Export des données (Admin)
  const handleExport = async () => {
    try {
      const data = await exportData();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `qualite-flowmap-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      alert('Erreur lors de l\'export : ' + (err instanceof Error ? err.message : 'Erreur'));
    }
  };

  // Import des données (Admin)
  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = async () => {
          const success = await importData(reader.result as string);
          if (success) {
            alert('Données importées avec succès !');
          } else {
            alert('Erreur lors de l\'import. Vérifiez le format du fichier.');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  // Reset (Admin)
  const handleReset = async () => {
    if (confirm('Êtes-vous sûr de vouloir réinitialiser toutes les données ? Cette action est irréversible.')) {
      try {
        await resetToDefaults();
        setSelectedNode(null);
        alert('Données réinitialisées !');
      } catch (err) {
        alert('Erreur lors de la réinitialisation : ' + (err instanceof Error ? err.message : 'Erreur'));
      }
    }
  };

  // Statistiques pour l'affichage
  const stats = useMemo(() => {
    let filteredCount = nodes.length;
    
    if (filters.phaseId || filters.laneId || filters.role || filters.search) {
      filteredCount = nodes.filter(node => {
        if (filters.phaseId && node.phaseId !== filters.phaseId) return false;
        if (filters.laneId && node.laneId !== filters.laneId) return false;
        if (filters.role) {
          const hasRole = node.mainRole === filters.role || 
            node.secondaryRoles?.includes(filters.role);
          if (!hasRole) return false;
        }
        if (filters.search) {
          const searchLower = filters.search.toLowerCase();
          const matches = 
            node.title.toLowerCase().includes(searchLower) ||
            node.shortDescription.toLowerCase().includes(searchLower) ||
            node.id.toLowerCase().includes(searchLower);
          if (!matches) return false;
        }
        return true;
      }).length;
    }
    
    return { total: nodes.length, filtered: filteredCount };
  }, [nodes, filters]);

  // V3.1 - Progression du projet
  const projectProgress = useMemo(() => {
    if (!selectedProject) return null;
    const done = selectedProject.steps.filter(s => s.status === 'done').length;
    const total = selectedProject.steps.length;
    return { done, total, percent: total > 0 ? Math.round((done / total) * 100) : 0 };
  }, [selectedProject]);

  // Écran de chargement
  if (isLoading) {
    return (
      <div className="app-loading">
        <div className="loading-spinner">⏳</div>
        <p>Connexion au serveur...</p>
      </div>
    );
  }

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-left">
          <h1>🏭 {metadata.title}</h1>
          <span className="header-version">
            v{metadata.version} • MAJ: {metadata.lastUpdate}
          </span>
        </div>
        
        <div className="header-center">
          {/* Onglets */}
          <div className="tabs">
            <button 
              className={`tab ${activeTab === 'flowmap' ? 'active' : ''}`}
              onClick={() => setActiveTab('flowmap')}
            >
              🗺️ Carte du flux
            </button>
            <button 
              className={`tab ${activeTab === 'architecture' ? 'active' : ''}`}
              onClick={() => setActiveTab('architecture')}
            >
              📁 Architecture dossiers
            </button>
            {isAdmin && (
              <button 
                className={`tab ${activeTab === 'admin' ? 'active' : ''}`}
                onClick={() => setActiveTab('admin')}
              >
                ⚙️ Administration
              </button>
            )}
          </div>
        </div>

        <div className="header-right">
          {/* Indicateur de connexion */}
          <span className={`connection-indicator ${isConnected ? 'connected' : 'disconnected'}`}>
            {isConnected ? '🟢 Connecté' : '🔴 Hors ligne'}
          </span>
          
          <div className="header-stats">
            {activeTab === 'flowmap' && (
              <span className="stat">
                {stats.filtered === stats.total 
                  ? `${stats.total} étapes`
                  : `${stats.filtered} / ${stats.total} étapes`
                }
              </span>
            )}
          </div>
          <UserModeToggle />
        </div>
      </header>

      {/* Bandeau d'erreur */}
      {error && (
        <div className="error-banner">
          <span>⚠️ {error}</span>
          <button onClick={refreshData}>🔄 Réessayer</button>
        </div>
      )}

      {/* V3.1 - Bandeau projet sélectionné */}
      {selectedProject && activeTab === 'flowmap' && (
        <div className="project-banner">
          <div className="project-banner-info">
            <span className="project-banner-label">📁 Projet actif :</span>
            <span className="project-banner-name">
              <strong>{selectedProject.affaireNumber}</strong> - {selectedProject.chantierName}
            </span>
            {projectProgress && (
              <span className="project-banner-progress">
                | Progression : {projectProgress.done}/{projectProgress.total} ({projectProgress.percent}%)
              </span>
            )}
          </div>
        </div>
      )}

      {/* Barre d'outils Admin */}
      {isAdmin && activeTab !== 'admin' && (
        <div className="admin-toolbar">
          <span className="admin-label">🔧 Outils Admin :</span>
          <button className="btn-admin" onClick={handleExport} disabled={!isConnected}>
            📤 Exporter
          </button>
          <button className="btn-admin" onClick={handleImport} disabled={!isConnected}>
            📥 Importer
          </button>
          <button className="btn-admin" onClick={refreshData}>
            🔄 Actualiser
          </button>
          <button className="btn-admin btn-danger" onClick={handleReset} disabled={!isConnected}>
            ♻️ Réinitialiser
          </button>
        </div>
      )}

      {/* Contenu selon l'onglet */}
      {activeTab === 'flowmap' ? (
        <div className="flowmap-layout">
          {/* V3.1 - Sidebar avec projets */}
          <aside className="sidebar-projects">
            <ProjectSelector />
          </aside>

          {/* Zone principale */}
          <div className="flowmap-main">
            {/* Barre de filtres */}
            <FilterBar
              phases={phases}
              lanes={lanes}
              filters={filters}
              onFilterChange={handleFilterChange}
              roles={roles}
            />

            {/* Carte du flux */}
            <main className="app-main">
              <FlowMap
                phases={phases}
                lanes={lanes}
                nodes={nodes}
                filters={filters}
                onNodeClick={handleNodeClick}
                selectedProject={selectedProject}
              />
            </main>
          </div>

          {/* Panneau de détail */}
          <StepPanel
            node={selectedNode}
            phase={selectedPhase}
            lane={selectedLane}
            onClose={handleClosePanel}
            stepStatus={getSelectedNodeStatus()}
            onValidateStep={getSelectedNodeStatus() === 'active' ? handleValidateStep : undefined}
          />
        </div>
      ) : activeTab === 'architecture' ? (
        <main className="app-main app-main-full">
          <ArchitectureViewer />
        </main>
      ) : (
        <main className="app-main app-main-full">
          <AdminSettings />
        </main>
      )}

      {/* Footer */}
      <footer className="app-footer">
        {activeTab === 'flowmap' ? (
          <p>
            💡 <strong>Astuce :</strong> 
            {selectedProject 
              ? ` Projet "${selectedProject.affaireNumber}" actif. Validez les étapes pour progresser.`
              : ' Sélectionnez un projet pour suivre sa progression, ou cliquez sur une étape pour voir les détails.'
            }
            {isAdmin && ' En mode Admin, vous pouvez modifier les fiches.'}
          </p>
        ) : activeTab === 'architecture' ? (
          <p>
            📁 <strong>Architecture :</strong> Ce document présente l'organisation 
            des dossiers QMS sur le serveur.
          </p>
        ) : (
          <p>
            ⚙️ <strong>Administration :</strong> Gérez les rôles, métiers et cartes du flux.
          </p>
        )}
      </footer>
    </div>
  );
}

/**
 * Application principale avec les providers
 */
function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </AuthProvider>
  );
}

export default App;
