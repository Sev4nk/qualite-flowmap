/**
 * Service API pour communiquer avec le backend
 * 
 * Configure l'URL du backend ici si nécessaire.
 * Par défaut : même machine, port 3001
 */

// URL du backend - à modifier si le serveur est sur une autre machine
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

/**
 * Helper pour les requêtes fetch avec gestion d'erreurs
 */
async function fetchAPI(endpoint: string, options: RequestInit = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        ...options.headers,
      },
    });
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Erreur serveur' }));
      throw new Error(error.error || `Erreur ${response.status}`);
    }
    
    return response;
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('Impossible de se connecter au serveur. Vérifiez que le backend est démarré.');
    }
    throw error;
  }
}

/**
 * Récupérer toutes les données du flux
 */
export async function getFlowData() {
  const response = await fetchAPI('/api/flow');
  return response.json();
}

/**
 * Initialiser les données (premier lancement)
 */
export async function initFlowData(flow: any) {
  const response = await fetchAPI('/api/flow/init', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ flow }),
  });
  return response.json();
}

/**
 * Mettre à jour un nœud
 */
export async function updateNode(nodeId: string, updates: any) {
  const response = await fetchAPI(`/api/nodes/${nodeId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  return response.json();
}

/**
 * Ajouter un document QMS à un nœud
 */
export async function addDocument(nodeId: string, document: any, file?: File) {
  const formData = new FormData();
  formData.append('code', document.code);
  formData.append('title', document.title);
  formData.append('type', document.type || 'OTHER');
  if (document.comment) formData.append('comment', document.comment);
  if (document.url) formData.append('url', document.url);
  if (file) formData.append('file', file);
  
  const response = await fetchAPI(`/api/nodes/${nodeId}/documents`, {
    method: 'POST',
    body: formData,
  });
  return response.json();
}

/**
 * Modifier un document QMS
 */
export async function updateDocument(nodeId: string, docIndex: number, document: any, file?: File) {
  const formData = new FormData();
  formData.append('code', document.code);
  formData.append('title', document.title);
  formData.append('type', document.type || 'OTHER');
  formData.append('comment', document.comment || '');
  formData.append('url', document.url || '');
  if (file) formData.append('file', file);
  
  const response = await fetchAPI(`/api/nodes/${nodeId}/documents/${docIndex}`, {
    method: 'PUT',
    body: formData,
  });
  return response.json();
}

/**
 * Supprimer un document QMS
 */
export async function deleteDocument(nodeId: string, docIndex: number) {
  const response = await fetchAPI(`/api/nodes/${nodeId}/documents/${docIndex}`, {
    method: 'DELETE',
  });
  return response.json();
}

/**
 * Obtenir l'URL de téléchargement d'un document
 */
export function getDocumentDownloadUrl(storedFileName: string) {
  return `${API_BASE_URL}/api/documents/${storedFileName}`;
}

/**
 * Upload du PDF d'architecture
 */
export async function uploadArchitecturePdf(file: File) {
  const formData = new FormData();
  formData.append('file', file);
  
  const response = await fetchAPI('/api/architecture', {
    method: 'POST',
    body: formData,
  });
  return response.json();
}

/**
 * Info sur le PDF d'architecture
 */
export async function getArchitectureInfo() {
  const response = await fetchAPI('/api/architecture/info');
  return response.json();
}

/**
 * URL du PDF d'architecture pour l'affichage
 */
export function getArchitecturePdfUrl() {
  return `${API_BASE_URL}/api/architecture`;
}

/**
 * Supprimer le PDF d'architecture
 */
export async function deleteArchitecturePdf() {
  const response = await fetchAPI('/api/architecture', {
    method: 'DELETE',
  });
  return response.json();
}

/**
 * Réinitialiser toutes les données
 */
export async function resetAllData() {
  const response = await fetchAPI('/api/reset', {
    method: 'POST',
  });
  return response.json();
}

/**
 * Exporter les données
 */
export async function exportData() {
  const response = await fetchAPI('/api/export');
  return response.json();
}

/**
 * Importer des données
 */
export async function importData(flow: any) {
  const response = await fetchAPI('/api/import', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ flow }),
  });
  return response.json();
}

// ============================================
// V3.1 - RÔLES
// ============================================

/**
 * Récupérer tous les rôles
 */
export async function getRoles() {
  const response = await fetchAPI('/api/roles');
  return response.json();
}

/**
 * Créer un rôle
 */
export async function createRole(name: string, color?: string) {
  const response = await fetchAPI('/api/roles', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, color }),
  });
  return response.json();
}

/**
 * Modifier un rôle
 */
export async function updateRole(id: string, updates: { name?: string; color?: string }) {
  const response = await fetchAPI(`/api/roles/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  return response.json();
}

/**
 * Supprimer un rôle
 */
export async function deleteRole(id: string) {
  const response = await fetchAPI(`/api/roles/${id}`, {
    method: 'DELETE',
  });
  return response.json();
}

// ============================================
// V3.1 - MÉTIERS
// ============================================

/**
 * Récupérer tous les métiers
 */
export async function getMetiers() {
  const response = await fetchAPI('/api/metiers');
  return response.json();
}

/**
 * Créer un métier
 */
export async function createMetier(name: string, color?: string, icon?: string) {
  const response = await fetchAPI('/api/metiers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, color, icon }),
  });
  return response.json();
}

/**
 * Modifier un métier
 */
export async function updateMetier(id: string, updates: { name?: string; color?: string; icon?: string }) {
  const response = await fetchAPI(`/api/metiers/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  return response.json();
}

/**
 * Supprimer un métier
 */
export async function deleteMetier(id: string) {
  const response = await fetchAPI(`/api/metiers/${id}`, {
    method: 'DELETE',
  });
  return response.json();
}

// ============================================
// V3.1 - PROJETS
// ============================================

/**
 * Récupérer tous les projets
 */
export async function getProjects() {
  const response = await fetchAPI('/api/projects');
  return response.json();
}

/**
 * Créer un projet
 */
export async function createProject(affaireNumber: string, chantierName: string) {
  const response = await fetchAPI('/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ affaireNumber, chantierName }),
  });
  return response.json();
}

/**
 * Récupérer un projet par ID
 */
export async function getProject(id: string) {
  const response = await fetchAPI(`/api/projects/${id}`);
  return response.json();
}

/**
 * Modifier un projet
 */
export async function updateProject(id: string, updates: any) {
  const response = await fetchAPI(`/api/projects/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  return response.json();
}

/**
 * Supprimer un projet
 */
export async function deleteProject(id: string) {
  const response = await fetchAPI(`/api/projects/${id}`, {
    method: 'DELETE',
  });
  return response.json();
}

/**
 * Avancer à l'étape suivante d'un projet
 */
export async function advanceProjectStep(projectId: string, comment?: string) {
  const response = await fetchAPI(`/api/projects/${projectId}/advance`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ comment }),
  });
  return response.json();
}

// ============================================
// V3.1 - GESTION DES CARTES (NODES)
// ============================================

/**
 * Créer une nouvelle carte
 */
export async function createNode(data: {
  title?: string;
  phaseId?: string;
  laneId?: string;
  shortDescription?: string;
  mainRole?: string;
}) {
  const response = await fetchAPI('/api/nodes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return response.json();
}

/**
 * Supprimer une carte
 */
export async function deleteNode(nodeId: string) {
  const response = await fetchAPI(`/api/nodes/${nodeId}`, {
    method: 'DELETE',
  });
  return response.json();
}
