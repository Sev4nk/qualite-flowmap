import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // Base URL pour le déploiement (modifier si nécessaire)
  base: './',
  build: {
    // Dossier de sortie pour le build de production
    outDir: 'dist',
    // Génère un fichier sourcemap pour le debug (optionnel)
    sourcemap: false
  }
})
