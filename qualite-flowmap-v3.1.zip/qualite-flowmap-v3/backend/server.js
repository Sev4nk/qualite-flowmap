/**
 * QUALITE Flowmap - Backend Server
 * 
 * Serveur Express.js pour centraliser les données sur le réseau local.
 * Stockage en fichiers JSON + dossier pour les uploads.
 * 
 * Endpoints :
 * - GET    /api/flow          → Récupérer toutes les données
 * - PUT    /api/nodes/:id     → Mettre à jour un nœud
 * - POST   /api/nodes/:id/documents      → Ajouter un document QMS
 * - PUT    /api/nodes/:id/documents/:idx → Modifier un document
 * - DELETE /api/nodes/:id/documents/:idx → Supprimer un document
 * - GET    /api/documents/:filename      → Télécharger un fichier
 * - POST   /api/architecture             → Upload PDF architecture
 * - GET    /api/architecture             → Récupérer PDF architecture
 * - DELETE /api/architecture             → Supprimer PDF architecture
 * - POST   /api/reset                    → Réinitialiser les données
 */

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;

// === Configuration ===

// Dossiers de données
const DATA_DIR = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const FLOW_FILE = path.join(DATA_DIR, 'flow.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const ROLES_FILE = path.join(DATA_DIR, 'roles.json');
const METIERS_FILE = path.join(DATA_DIR, 'metiers.json');
const PROJECTS_FILE = path.join(DATA_DIR, 'projects.json');

// Créer les dossiers s'ils n'existent pas
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// Configuration multer pour l'upload de fichiers
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    // Générer un nom unique avec timestamp
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, uniqueSuffix + ext);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 } // Max 10 Mo
});

// === Middlewares ===

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Logger simple
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// === Fonctions utilitaires ===

// Charger les données du flux
function loadFlowData() {
  if (fs.existsSync(FLOW_FILE)) {
    const raw = fs.readFileSync(FLOW_FILE, 'utf-8');
    return JSON.parse(raw);
  }
  // Données par défaut (sera initialisé par le frontend)
  return null;
}

// Sauvegarder les données du flux
function saveFlowData(data) {
  fs.writeFileSync(FLOW_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// Charger les paramètres
function loadSettings() {
  if (fs.existsSync(SETTINGS_FILE)) {
    const raw = fs.readFileSync(SETTINGS_FILE, 'utf-8');
    return JSON.parse(raw);
  }
  return { architecturePdf: null };
}

// Sauvegarder les paramètres
function saveSettings(settings) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf-8');
}

// === V3.1 - Rôles ===

// Rôles par défaut
const DEFAULT_ROLES = [
  { id: 'role-commerce', name: 'Commerce', color: '#e74c3c' },
  { id: 'role-adv', name: 'ADV', color: '#3498db' },
  { id: 'role-be-calcul', name: 'BE Calcul', color: '#9b59b6' },
  { id: 'role-be-etude', name: 'BE Étude', color: '#2ecc71' },
  { id: 'role-achats', name: 'Achats', color: '#f39c12' },
  { id: 'role-methodes', name: 'Méthodes', color: '#1abc9c' },
  { id: 'role-production', name: 'Production', color: '#e67e22' },
  { id: 'role-qualite', name: 'Contrôle Qualité', color: '#34495e' },
  { id: 'role-logistique', name: 'Logistique', color: '#95a5a6' }
];

function loadRoles() {
  if (fs.existsSync(ROLES_FILE)) {
    const raw = fs.readFileSync(ROLES_FILE, 'utf-8');
    return JSON.parse(raw);
  }
  return DEFAULT_ROLES;
}

function saveRoles(roles) {
  fs.writeFileSync(ROLES_FILE, JSON.stringify(roles, null, 2), 'utf-8');
}

// === V3.1 - Métiers ===

// Métiers par défaut (correspondent aux Lanes existantes)
const DEFAULT_METIERS = [
  { id: 'metier-commerce', name: 'Commerce', color: '#E57373', icon: '💼', order: 1 },
  { id: 'metier-calcul', name: 'Calcul', color: '#BA68C8', icon: '🔢', order: 2 },
  { id: 'metier-etude', name: 'Étude', color: '#64B5F6', icon: '📐', order: 3 },
  { id: 'metier-appro', name: 'Approvisionnement', color: '#FFD54F', icon: '📦', order: 4 },
  { id: 'metier-indus', name: 'Industrialisation', color: '#81C784', icon: '⚙️', order: 5 },
  { id: 'metier-planif', name: 'Planification', color: '#4DB6AC', icon: '📅', order: 6 },
  { id: 'metier-prod', name: 'Production', color: '#FF8A65', icon: '🏭', order: 7 },
  { id: 'metier-exped', name: 'Expédition', color: '#A1887F', icon: '🚚', order: 8 },
  { id: 'metier-montage', name: 'Montage', color: '#90A4AE', icon: '🔧', order: 9 }
];

function loadMetiers() {
  if (fs.existsSync(METIERS_FILE)) {
    const raw = fs.readFileSync(METIERS_FILE, 'utf-8');
    return JSON.parse(raw);
  }
  return DEFAULT_METIERS;
}

function saveMetiers(metiers) {
  fs.writeFileSync(METIERS_FILE, JSON.stringify(metiers, null, 2), 'utf-8');
}

// === V3.1 - Projets ===

function loadProjects() {
  if (fs.existsSync(PROJECTS_FILE)) {
    const raw = fs.readFileSync(PROJECTS_FILE, 'utf-8');
    return JSON.parse(raw);
  }
  return [];
}

function saveProjects(projects) {
  fs.writeFileSync(PROJECTS_FILE, JSON.stringify(projects, null, 2), 'utf-8');
}

// Générer un ID unique
function generateId(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// === Routes API ===

// GET /api/flow - Récupérer toutes les données
app.get('/api/flow', (req, res) => {
  const flowData = loadFlowData();
  const settings = loadSettings();
  
  res.json({
    flow: flowData,
    settings: settings
  });
});

// POST /api/flow/init - Initialiser les données (premier lancement)
app.post('/api/flow/init', (req, res) => {
  const { flow } = req.body;
  
  if (!flow) {
    return res.status(400).json({ error: 'Données manquantes' });
  }
  
  // Ne sauvegarder que si le fichier n'existe pas
  if (!fs.existsSync(FLOW_FILE)) {
    saveFlowData(flow);
    console.log('✅ Données initialisées');
  }
  
  res.json({ success: true });
});

// PUT /api/nodes/:id - Mettre à jour un nœud
app.put('/api/nodes/:id', (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  
  const flowData = loadFlowData();
  if (!flowData) {
    return res.status(404).json({ error: 'Données non initialisées' });
  }
  
  const nodeIndex = flowData.nodes.findIndex(n => n.id === id);
  if (nodeIndex === -1) {
    return res.status(404).json({ error: 'Nœud non trouvé' });
  }
  
  // Mettre à jour le nœud (sans écraser les documents QMS)
  flowData.nodes[nodeIndex] = {
    ...flowData.nodes[nodeIndex],
    ...updates,
    qmsDocuments: flowData.nodes[nodeIndex].qmsDocuments // Préserver les docs
  };
  
  saveFlowData(flowData);
  res.json({ success: true, node: flowData.nodes[nodeIndex] });
});

// POST /api/nodes/:id/documents - Ajouter un document QMS
app.post('/api/nodes/:id/documents', upload.single('file'), (req, res) => {
  const { id } = req.params;
  const { code, title, type, comment, url } = req.body;
  
  const flowData = loadFlowData();
  if (!flowData) {
    return res.status(404).json({ error: 'Données non initialisées' });
  }
  
  const nodeIndex = flowData.nodes.findIndex(n => n.id === id);
  if (nodeIndex === -1) {
    return res.status(404).json({ error: 'Nœud non trouvé' });
  }
  
  // Créer le document
  const newDoc = {
    code,
    title,
    type: type || 'OTHER',
    comment: comment || undefined,
    url: url || undefined
  };
  
  // Si un fichier a été uploadé
  if (req.file) {
    newDoc.fileName = req.file.originalname;
    newDoc.storedFileName = req.file.filename;
  }
  
  // Ajouter au nœud
  if (!flowData.nodes[nodeIndex].qmsDocuments) {
    flowData.nodes[nodeIndex].qmsDocuments = [];
  }
  flowData.nodes[nodeIndex].qmsDocuments.push(newDoc);
  
  saveFlowData(flowData);
  res.json({ success: true, document: newDoc });
});

// PUT /api/nodes/:id/documents/:idx - Modifier un document QMS
app.put('/api/nodes/:id/documents/:idx', upload.single('file'), (req, res) => {
  const { id, idx } = req.params;
  const docIndex = parseInt(idx, 10);
  const { code, title, type, comment, url } = req.body;
  
  const flowData = loadFlowData();
  if (!flowData) {
    return res.status(404).json({ error: 'Données non initialisées' });
  }
  
  const nodeIndex = flowData.nodes.findIndex(n => n.id === id);
  if (nodeIndex === -1) {
    return res.status(404).json({ error: 'Nœud non trouvé' });
  }
  
  const docs = flowData.nodes[nodeIndex].qmsDocuments || [];
  if (docIndex < 0 || docIndex >= docs.length) {
    return res.status(404).json({ error: 'Document non trouvé' });
  }
  
  // Supprimer l'ancien fichier si un nouveau est uploadé
  if (req.file && docs[docIndex].storedFileName) {
    const oldFilePath = path.join(UPLOADS_DIR, docs[docIndex].storedFileName);
    if (fs.existsSync(oldFilePath)) {
      fs.unlinkSync(oldFilePath);
    }
  }
  
  // Mettre à jour le document
  docs[docIndex] = {
    ...docs[docIndex],
    code: code || docs[docIndex].code,
    title: title || docs[docIndex].title,
    type: type || docs[docIndex].type,
    comment: comment !== undefined ? comment : docs[docIndex].comment,
    url: url !== undefined ? url : docs[docIndex].url
  };
  
  if (req.file) {
    docs[docIndex].fileName = req.file.originalname;
    docs[docIndex].storedFileName = req.file.filename;
  }
  
  saveFlowData(flowData);
  res.json({ success: true, document: docs[docIndex] });
});

// DELETE /api/nodes/:id/documents/:idx - Supprimer un document QMS
app.delete('/api/nodes/:id/documents/:idx', (req, res) => {
  const { id, idx } = req.params;
  const docIndex = parseInt(idx, 10);
  
  const flowData = loadFlowData();
  if (!flowData) {
    return res.status(404).json({ error: 'Données non initialisées' });
  }
  
  const nodeIndex = flowData.nodes.findIndex(n => n.id === id);
  if (nodeIndex === -1) {
    return res.status(404).json({ error: 'Nœud non trouvé' });
  }
  
  const docs = flowData.nodes[nodeIndex].qmsDocuments || [];
  if (docIndex < 0 || docIndex >= docs.length) {
    return res.status(404).json({ error: 'Document non trouvé' });
  }
  
  // Supprimer le fichier associé
  if (docs[docIndex].storedFileName) {
    const filePath = path.join(UPLOADS_DIR, docs[docIndex].storedFileName);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  }
  
  // Retirer du tableau
  docs.splice(docIndex, 1);
  
  saveFlowData(flowData);
  res.json({ success: true });
});

// GET /api/documents/:filename - Télécharger un fichier
app.get('/api/documents/:filename', (req, res) => {
  const { filename } = req.params;
  const filePath = path.join(UPLOADS_DIR, filename);
  
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Fichier non trouvé' });
  }
  
  res.download(filePath);
});

// POST /api/architecture - Upload PDF architecture
app.post('/api/architecture', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Aucun fichier fourni' });
  }
  
  const settings = loadSettings();
  
  // Supprimer l'ancien PDF si existant
  if (settings.architecturePdf) {
    const oldPath = path.join(UPLOADS_DIR, settings.architecturePdf);
    if (fs.existsSync(oldPath)) {
      fs.unlinkSync(oldPath);
    }
  }
  
  // Sauvegarder le nouveau
  settings.architecturePdf = req.file.filename;
  settings.architecturePdfOriginalName = req.file.originalname;
  saveSettings(settings);
  
  res.json({ 
    success: true, 
    filename: req.file.filename,
    originalName: req.file.originalname
  });
});

// GET /api/architecture - Récupérer le PDF architecture
app.get('/api/architecture', (req, res) => {
  const settings = loadSettings();
  
  if (!settings.architecturePdf) {
    return res.status(404).json({ error: 'Aucun PDF d\'architecture' });
  }
  
  const filePath = path.join(UPLOADS_DIR, settings.architecturePdf);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Fichier non trouvé' });
  }
  
  res.download(filePath, settings.architecturePdfOriginalName || 'architecture.pdf');
});

// GET /api/architecture/info - Info sur le PDF architecture
app.get('/api/architecture/info', (req, res) => {
  const settings = loadSettings();
  
  if (!settings.architecturePdf) {
    return res.json({ exists: false });
  }
  
  const filePath = path.join(UPLOADS_DIR, settings.architecturePdf);
  res.json({ 
    exists: fs.existsSync(filePath),
    filename: settings.architecturePdf,
    originalName: settings.architecturePdfOriginalName
  });
});

// DELETE /api/architecture - Supprimer le PDF architecture
app.delete('/api/architecture', (req, res) => {
  const settings = loadSettings();
  
  if (settings.architecturePdf) {
    const filePath = path.join(UPLOADS_DIR, settings.architecturePdf);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  }
  
  settings.architecturePdf = null;
  settings.architecturePdfOriginalName = null;
  saveSettings(settings);
  
  res.json({ success: true });
});

// ============================================
// V3.1 - ROUTES POUR LES RÔLES
// ============================================

// GET /api/roles - Récupérer tous les rôles
app.get('/api/roles', (req, res) => {
  const roles = loadRoles();
  res.json({ roles });
});

// POST /api/roles - Créer un rôle
app.post('/api/roles', (req, res) => {
  const { name, color } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Nom requis' });
  }
  
  const roles = loadRoles();
  const newRole = {
    id: generateId('role'),
    name,
    color: color || '#3498db'
  };
  
  roles.push(newRole);
  saveRoles(roles);
  res.json({ success: true, role: newRole });
});

// PUT /api/roles/:id - Modifier un rôle
app.put('/api/roles/:id', (req, res) => {
  const { id } = req.params;
  const { name, color } = req.body;
  
  const roles = loadRoles();
  const index = roles.findIndex(r => r.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Rôle non trouvé' });
  }
  
  roles[index] = { ...roles[index], name: name || roles[index].name, color: color || roles[index].color };
  saveRoles(roles);
  res.json({ success: true, role: roles[index] });
});

// DELETE /api/roles/:id - Supprimer un rôle
app.delete('/api/roles/:id', (req, res) => {
  const { id } = req.params;
  
  let roles = loadRoles();
  roles = roles.filter(r => r.id !== id);
  saveRoles(roles);
  
  res.json({ success: true });
});

// ============================================
// V3.1 - ROUTES POUR LES MÉTIERS
// ============================================

// GET /api/metiers - Récupérer tous les métiers
app.get('/api/metiers', (req, res) => {
  const metiers = loadMetiers();
  res.json({ metiers });
});

// POST /api/metiers - Créer un métier
app.post('/api/metiers', (req, res) => {
  const { name, color, icon } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Nom requis' });
  }
  
  const metiers = loadMetiers();
  const newMetier = {
    id: generateId('metier'),
    name,
    color: color || '#95a5a6',
    icon: icon || '📁',
    order: metiers.length + 1
  };
  
  metiers.push(newMetier);
  saveMetiers(metiers);
  res.json({ success: true, metier: newMetier });
});

// PUT /api/metiers/:id - Modifier un métier
app.put('/api/metiers/:id', (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  
  const metiers = loadMetiers();
  const index = metiers.findIndex(m => m.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Métier non trouvé' });
  }
  
  metiers[index] = { ...metiers[index], ...updates };
  saveMetiers(metiers);
  res.json({ success: true, metier: metiers[index] });
});

// DELETE /api/metiers/:id - Supprimer un métier
app.delete('/api/metiers/:id', (req, res) => {
  const { id } = req.params;
  
  let metiers = loadMetiers();
  metiers = metiers.filter(m => m.id !== id);
  saveMetiers(metiers);
  
  res.json({ success: true });
});

// ============================================
// V3.1 - ROUTES POUR LES PROJETS
// ============================================

// GET /api/projects - Récupérer tous les projets
app.get('/api/projects', (req, res) => {
  const projects = loadProjects();
  res.json({ projects });
});

// POST /api/projects - Créer un projet
app.post('/api/projects', (req, res) => {
  const { affaireNumber, chantierName } = req.body;
  if (!affaireNumber || !chantierName) {
    return res.status(400).json({ error: 'N° affaire et nom chantier requis' });
  }
  
  const flowData = loadFlowData();
  if (!flowData || !flowData.nodes) {
    return res.status(400).json({ error: 'Flux non initialisé' });
  }
  
  // Créer les étapes basées sur les nœuds existants (triés par phase puis ordre)
  const sortedNodes = [...flowData.nodes].sort((a, b) => {
    if (a.phaseId !== b.phaseId) {
      return a.phaseId.localeCompare(b.phaseId);
    }
    return (a.order || 0) - (b.order || 0);
  });
  
  const steps = sortedNodes.map((node, index) => ({
    nodeId: node.id,
    status: index === 0 ? 'active' : 'locked'
  }));
  
  const projects = loadProjects();
  const newProject = {
    id: generateId('proj'),
    affaireNumber,
    chantierName,
    createdAt: new Date().toISOString(),
    steps
  };
  
  projects.push(newProject);
  saveProjects(projects);
  res.json({ success: true, project: newProject });
});

// GET /api/projects/:id - Récupérer un projet
app.get('/api/projects/:id', (req, res) => {
  const { id } = req.params;
  const projects = loadProjects();
  const project = projects.find(p => p.id === id);
  
  if (!project) {
    return res.status(404).json({ error: 'Projet non trouvé' });
  }
  
  res.json({ project });
});

// PUT /api/projects/:id - Modifier un projet
app.put('/api/projects/:id', (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  
  const projects = loadProjects();
  const index = projects.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Projet non trouvé' });
  }
  
  projects[index] = { 
    ...projects[index], 
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveProjects(projects);
  res.json({ success: true, project: projects[index] });
});

// DELETE /api/projects/:id - Supprimer un projet
app.delete('/api/projects/:id', (req, res) => {
  const { id } = req.params;
  
  let projects = loadProjects();
  projects = projects.filter(p => p.id !== id);
  saveProjects(projects);
  
  res.json({ success: true });
});

// POST /api/projects/:id/advance - Avancer à l'étape suivante
app.post('/api/projects/:id/advance', (req, res) => {
  const { id } = req.params;
  const { comment } = req.body;
  
  const projects = loadProjects();
  const index = projects.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Projet non trouvé' });
  }
  
  const project = projects[index];
  const activeIndex = project.steps.findIndex(s => s.status === 'active');
  
  if (activeIndex === -1) {
    return res.status(400).json({ error: 'Aucune étape active' });
  }
  
  // Marquer l'étape courante comme done
  project.steps[activeIndex].status = 'done';
  project.steps[activeIndex].completedAt = new Date().toISOString();
  if (comment) {
    project.steps[activeIndex].comment = comment;
  }
  
  // Activer la suivante si elle existe
  if (activeIndex + 1 < project.steps.length) {
    project.steps[activeIndex + 1].status = 'active';
  }
  
  project.updatedAt = new Date().toISOString();
  saveProjects(projects);
  
  res.json({ success: true, project });
});

// ============================================
// V3.1 - GESTION DES CARTES (NODES)
// ============================================

// POST /api/nodes - Créer une nouvelle carte
app.post('/api/nodes', (req, res) => {
  const { title, phaseId, laneId, shortDescription, mainRole } = req.body;
  
  const flowData = loadFlowData();
  if (!flowData) {
    return res.status(404).json({ error: 'Données non initialisées' });
  }
  
  const newNode = {
    id: generateId('node'),
    title: title || 'Nouvelle étape',
    phaseId: phaseId || 'I',
    laneId: laneId || 'commerce',
    shortDescription: shortDescription || '',
    mainRole: mainRole || '',
    secondaryRoles: [],
    qmsDocuments: [],
    conditions: [],
    notes: '',
    order: flowData.nodes.length + 1
  };
  
  flowData.nodes.push(newNode);
  saveFlowData(flowData);
  
  res.json({ success: true, node: newNode });
});

// DELETE /api/nodes/:id - Supprimer une carte
app.delete('/api/nodes/:id', (req, res) => {
  const { id } = req.params;
  
  const flowData = loadFlowData();
  if (!flowData) {
    return res.status(404).json({ error: 'Données non initialisées' });
  }
  
  const nodeIndex = flowData.nodes.findIndex(n => n.id === id);
  if (nodeIndex === -1) {
    return res.status(404).json({ error: 'Nœud non trouvé' });
  }
  
  // Supprimer les fichiers associés aux documents QMS
  const node = flowData.nodes[nodeIndex];
  if (node.qmsDocuments) {
    for (const doc of node.qmsDocuments) {
      if (doc.storedFileName) {
        const filePath = path.join(UPLOADS_DIR, doc.storedFileName);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }
    }
  }
  
  flowData.nodes.splice(nodeIndex, 1);
  saveFlowData(flowData);
  
  res.json({ success: true });
});

// POST /api/reset - Réinitialiser les données
app.post('/api/reset', (req, res) => {
  // Supprimer tous les fichiers uploadés
  const files = fs.readdirSync(UPLOADS_DIR);
  for (const file of files) {
    fs.unlinkSync(path.join(UPLOADS_DIR, file));
  }
  
  // Supprimer les fichiers de données
  if (fs.existsSync(FLOW_FILE)) fs.unlinkSync(FLOW_FILE);
  if (fs.existsSync(SETTINGS_FILE)) fs.unlinkSync(SETTINGS_FILE);
  if (fs.existsSync(ROLES_FILE)) fs.unlinkSync(ROLES_FILE);
  if (fs.existsSync(METIERS_FILE)) fs.unlinkSync(METIERS_FILE);
  if (fs.existsSync(PROJECTS_FILE)) fs.unlinkSync(PROJECTS_FILE);
  
  console.log('🔄 Données réinitialisées');
  res.json({ success: true });
});

// POST /api/export - Exporter toutes les données
app.get('/api/export', (req, res) => {
  const flowData = loadFlowData();
  const settings = loadSettings();
  
  res.json({
    flow: flowData,
    settings: settings,
    exportedAt: new Date().toISOString()
  });
});

// POST /api/import - Importer des données
app.post('/api/import', (req, res) => {
  const { flow } = req.body;
  
  if (!flow) {
    return res.status(400).json({ error: 'Données manquantes' });
  }
  
  saveFlowData(flow);
  res.json({ success: true });
});

// === Démarrage du serveur ===

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('🏭 ═══════════════════════════════════════════════════════');
  console.log('   QUALITE Flowmap - Backend Server');
  console.log('═══════════════════════════════════════════════════════════');
  console.log('');
  console.log(`   📡 Serveur démarré sur le port ${PORT}`);
  console.log('');
  console.log('   Accès local :     http://localhost:' + PORT);
  console.log('   Accès réseau :    http://<IP_DU_PC>:' + PORT);
  console.log('');
  console.log('   📁 Données :      ' + DATA_DIR);
  console.log('   📎 Uploads :      ' + UPLOADS_DIR);
  console.log('');
  console.log('═══════════════════════════════════════════════════════════');
  console.log('');
});
