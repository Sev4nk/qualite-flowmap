# 🏭 QUALITE Flowmap V3.1

Application web de visualisation du flux de fabrication d'un réservoir (FP001).

**Architecture Client/Serveur** - Données centralisées sur le réseau local.

## 🆕 Nouveautés V3.1

### 📋 Gestion des cartes d'action (Admin)
- **Ajouter** une nouvelle carte d'action (étape du flux)
- **Supprimer** une carte existante
- **Modifier** le contenu de chaque carte
- Sections obligatoires sur chaque carte :
  - 📋 Objectif
  - 👥 Responsabilités
  - 📄 Documents QMS
  - 🚦 Conditions GO / NO GO
  - 💡 Notes & Rappels

### 👤 Rôles et métiers paramétrables (Admin)
- Liste des **rôles** modifiable (ADV, Commerce, Achats, etc.)
- Liste des **métiers** modifiable (Commerce, Calcul, Étude, etc.)
- Les champs "Responsabilités" utilisent des **listes déroulantes** (pas de texte libre)
- Garantit la cohérence pour les filtres par rôle/métier

### 📁 Gestion de projets avec progression
- Créer un **projet** avec N° d'affaire et nom de chantier
- Chaque projet initialise une **progression par étapes**
- **Première étape active**, les suivantes sont verrouillées
- Bouton "**Étape OK**" pour valider et passer à la suivante
- Visualisation de la progression (grisé / actif / terminé)
- Barre de progression avec pourcentage

---

## 📋 Fonctionnalités existantes

### 🗺️ Carte du flux
- Grille visuelle 9 phases × 9 colonnes métiers
- Panneau de détail pour chaque étape
- Filtres par phase, métier, rôle, recherche

### 👤 Modes Utilisateur / Admin
- **Mode Utilisateur** : Consultation, téléchargement, progression des projets
- **Mode Admin** : Modification complète des fiches, documents, rôles, métiers, cartes

### 📄 Gestion des documents QMS
- Upload de fichiers sur le serveur (max 10 Mo)
- Téléchargement par tous les utilisateurs
- Support PDF, Word, Excel, PowerPoint

### 📁 Architecture des dossiers
- Visualisation du PDF FM_F550_Compliance_Matrix
- Stockage centralisé sur le serveur

### 💾 Données centralisées
- **Toutes les données sont partagées** entre les utilisateurs
- Stockage sur le serveur en fichiers JSON + uploads
- Pas besoin d'internet

---

## 🚀 Installation

### Option 1 : Scripts Windows (recommandé)

1. **Installation** : Double-cliquez sur `install.bat`
2. **Démarrage** : Double-cliquez sur `start.bat`

### Option 2 : Ligne de commande

#### 1. Backend (serveur)

```bash
cd backend
npm install
npm start
```

Le serveur démarre sur le port **3001**.

#### 2. Frontend (client)

Dans un autre terminal :

```bash
cd frontend
npm install
npm run dev
```

L'application est accessible sur http://localhost:5173

---

## 🌐 Accès réseau (autres PC)

### Sur le PC serveur

1. Notez l'adresse IP du PC (ex: `192.168.1.100`)
2. Lancez le backend : `npm start`
3. Lancez le frontend avec l'IP :

```bash
cd frontend
set VITE_API_URL=http://192.168.1.100:3001
npm run dev -- --host
```

### Sur les autres PC

Ouvrez un navigateur et accédez à :
```
http://192.168.1.100:5173
```

---

## 📦 Build de production

### Frontend

```bash
cd frontend
npm run build
```

Le dossier `dist/` contient les fichiers statiques.

### Déployer

1. Copiez `backend/` sur le serveur
2. Copiez `frontend/dist/` sur le serveur web (ou servez avec le backend)
3. Lancez `npm start` dans le backend

---

## 🔐 Accès Admin

Mot de passe par défaut : **`admin123`**

Pour modifier, éditez `frontend/src/context/AuthContext.tsx` :
```typescript
const ADMIN_PASSWORD = 'votre_mot_de_passe';
```

---

## 📁 Structure du projet

```
qualite-flowmap-v3/
├── backend/
│   ├── data/
│   │   ├── flow.json       # Données des nœuds
│   │   ├── settings.json   # Paramètres
│   │   ├── roles.json      # V3.1 - Rôles
│   │   ├── metiers.json    # V3.1 - Métiers
│   │   └── projects.json   # V3.1 - Projets
│   ├── uploads/            # Fichiers uploadés
│   ├── server.js           # Serveur Express
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── FlowMap.tsx
│   │   │   ├── StepPanel.tsx
│   │   │   ├── NodeCard.tsx
│   │   │   ├── FilterBar.tsx
│   │   │   ├── ArchitectureViewer.tsx
│   │   │   ├── ProjectSelector.tsx   # V3.1
│   │   │   ├── AdminSettings.tsx     # V3.1
│   │   │   └── UserModeToggle.tsx
│   │   ├── context/
│   │   │   ├── AuthContext.tsx
│   │   │   └── DataContext.tsx
│   │   ├── services/
│   │   │   └── api.ts
│   │   ├── data/
│   │   │   └── flow.json   # Données initiales
│   │   └── types/
│   │       └── index.ts
│   ├── package.json
│   └── vite.config.ts
│
├── install.bat
├── start.bat
└── README.md
```

---

## 🔧 Configuration

### Changer le port du backend

Dans `backend/server.js`, modifiez :
```javascript
const PORT = process.env.PORT || 3001;
```

### Changer l'URL de l'API

Dans `frontend/src/services/api.ts` :
```typescript
const API_BASE_URL = 'http://IP_DU_SERVEUR:3001';
```

Ou utilisez la variable d'environnement :
```bash
set VITE_API_URL=http://192.168.1.100:3001
npm run dev
```

---

## 💾 Sauvegarde des données

Les données sont stockées dans :
- `backend/data/flow.json` - Données des nœuds/cartes
- `backend/data/settings.json` - Paramètres
- `backend/data/roles.json` - Rôles (V3.1)
- `backend/data/metiers.json` - Métiers (V3.1)
- `backend/data/projects.json` - Projets (V3.1)
- `backend/uploads/` - Fichiers uploadés

**Pour sauvegarder :** copiez ces dossiers.

---

## 🔄 Fonctionnement

```
┌─────────────┐         ┌─────────────┐
│  PC Client  │  HTTP   │ PC Serveur  │
│  (Browser)  │◄───────►│  (Node.js)  │
└─────────────┘         └─────────────┘
                              │
                              ▼
                        ┌─────────────┐
                        │   Fichiers  │
                        │  JSON + PDF │
                        └─────────────┘
```

- Le frontend (React) tourne dans le navigateur
- Il communique avec le backend (Express) via HTTP
- Le backend stocke tout dans des fichiers locaux

---

## 📝 Notes

- **Port 3001** : Backend API
- **Port 5173** : Frontend dev server
- Les données sont **automatiquement sauvegardées** après chaque modification
- Le frontend se reconnecte automatiquement si le serveur redémarre

---

## 🛠️ Stack technique

- **Frontend** : React 18, TypeScript, Vite
- **Backend** : Node.js, Express
- **Stockage** : Fichiers JSON, uploads sur disque

---

Développé pour la gestion qualité des réservoirs FM TANK 🏭
